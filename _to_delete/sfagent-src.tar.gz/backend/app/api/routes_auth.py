"""Application session endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Response
from pydantic import BaseModel, EmailStr

from app.config import settings
from app.security.auth import (
    SESSION_COOKIE,
    CurrentUser,
    DbSession,
    create_session_token,
    get_or_create_user,
)

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    email: EmailStr
    display_name: str = ""


class UserOut(BaseModel):
    id: str
    email: str
    display_name: str


@router.post("/login", response_model=UserOut)
async def login(payload: LoginRequest, response: Response, db: DbSession) -> UserOut:
    user = await get_or_create_user(db, str(payload.email), payload.display_name)
    await db.commit()
    token = create_session_token(user.id)
    response.set_cookie(
        SESSION_COOKIE,
        token,
        httponly=True,
        samesite="lax",
        secure=settings.environment not in {"local", "dev"},
        max_age=settings.session_ttl_seconds,
        path="/",
    )
    return UserOut(id=user.id, email=user.email, display_name=user.display_name)


@router.post("/logout")
async def logout(response: Response) -> dict[str, bool]:
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"success": True}


@router.get("/me", response_model=UserOut)
async def me(user: CurrentUser) -> UserOut:
    return UserOut(id=user.id, email=user.email, display_name=user.display_name)
