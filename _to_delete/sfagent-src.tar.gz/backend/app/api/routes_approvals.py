"""Human-in-the-loop approval endpoints.

An approval is only ever created by the runtime and only ever decided by an
explicit call to this endpoint. Nothing in a chat message can approve a change.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select

from app.models import AgentRun, AgentState, Approval, ApprovalState, AuditLog
from app.security.auth import CurrentUser, DbSession

router = APIRouter(prefix="/approvals", tags=["approvals"])


class Decision(BaseModel):
    decision: Literal["approve", "reject"]
    note: str | None = None
    modified_arguments: dict[str, Any] | None = None


def _out(a: Approval) -> dict[str, Any]:
    return {
        "id": a.id,
        "agent_run_id": a.agent_run_id,
        "conversation_id": a.conversation_id,
        "tool_name": a.tool_name,
        "risk_level": a.risk_level.value,
        "state": a.state.value,
        "arguments": a.arguments,
        "modified_arguments": a.modified_arguments,
        "plan": a.plan,
        "decision_note": a.decision_note,
        "decided_at": a.decided_at.isoformat() if a.decided_at else None,
        "created_at": a.created_at.isoformat(),
    }


@router.get("")
async def list_approvals(
    user: CurrentUser,
    db: DbSession,
    state: str | None = Query(None),
    conversation_id: str | None = Query(None),
    limit: int = Query(50, le=200),
) -> dict[str, Any]:
    stmt = select(Approval).where(Approval.user_id == user.id)
    if state:
        stmt = stmt.where(Approval.state == ApprovalState(state.upper()))
    if conversation_id:
        stmt = stmt.where(Approval.conversation_id == conversation_id)
    rows = (
        (await db.execute(stmt.order_by(Approval.created_at.desc()).limit(limit)))
        .scalars()
        .all()
    )
    return {"count": len(rows), "approvals": [_out(a) for a in rows]}


@router.get("/{approval_id}")
async def get_approval(approval_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    approval = await _owned(db, user.id, approval_id)
    return _out(approval)


@router.post("/{approval_id}/decision")
async def decide(
    approval_id: str, payload: Decision, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    approval = await _owned(db, user.id, approval_id)
    if approval.state != ApprovalState.PENDING:
        raise HTTPException(
            status_code=409,
            detail=f"Approval is already {approval.state.value} and cannot be changed.",
        )

    approval.state = (
        ApprovalState.APPROVED if payload.decision == "approve" else ApprovalState.REJECTED
    )
    approval.decided_by = user.id
    approval.decided_at = datetime.now(UTC)
    approval.decision_note = payload.note
    if payload.decision == "approve" and payload.modified_arguments:
        approval.modified_arguments = payload.modified_arguments

    db.add(
        AuditLog(
            user_id=user.id,
            org_connection_id=approval.org_connection_id,
            conversation_id=approval.conversation_id,
            agent_run_id=approval.agent_run_id,
            action=f"approval.{payload.decision}d",
            tool_name=approval.tool_name,
            arguments=approval.modified_arguments or approval.arguments,
            risk_level=approval.risk_level,
            approval_state=approval.state,
            outcome="ok",
        )
    )
    await db.commit()

    run = await db.get(AgentRun, approval.agent_run_id)
    pending = (
        (
            await db.execute(
                select(Approval).where(
                    Approval.agent_run_id == approval.agent_run_id,
                    Approval.state == ApprovalState.PENDING,
                )
            )
        )
        .scalars()
        .all()
    )
    return {
        "success": True,
        "approval": _out(approval),
        "run_id": approval.agent_run_id,
        "run_state": run.state.value if run else None,
        "pending_approvals": [a.id for a in pending],
        "resume_ready": bool(run and run.state == AgentState.AWAITING_APPROVAL and not pending),
    }


async def _owned(db: Any, user_id: str, approval_id: str) -> Approval:
    approval = await db.get(Approval, approval_id)
    if approval is None or approval.user_id != user_id:
        raise HTTPException(status_code=404, detail="Approval not found")
    return approval
