"""Agent execution endpoints (SSE streaming execution trace)."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.agent.runtime import AgentRuntime
from app.api.routes_conversations import _owned as owned_conversation
from app.api.routes_salesforce import resolve_connection
from app.models import AgentRun, AgentState
from app.observability.logging import get_logger
from app.security.auth import CurrentUser, DbSession
from app.tools.registry import build_registry

router = APIRouter(tags=["agent"])
log = get_logger("api.agent")


class SendMessage(BaseModel):
    message: str = Field(min_length=1, max_length=20_000)


def _sse(event: dict[str, Any]) -> str:
    return f"event: {event['type']}\ndata: {json.dumps(event['data'], default=str)}\n\n"


async def _stream(events: AsyncIterator[dict[str, Any]]) -> AsyncIterator[str]:
    try:
        async for event in events:
            yield _sse(event)
    except Exception as exc:
        log.error("agent.stream_error", exc_info=True)
        yield _sse({"type": "error", "data": {"message": str(exc)}})
    finally:
        yield _sse({"type": "stream.end", "data": {}})


@router.post("/conversations/{conversation_id}/messages")
async def send_message(
    conversation_id: str, payload: SendMessage, user: CurrentUser, db: DbSession
) -> StreamingResponse:
    conversation = await owned_conversation(db, user.id, conversation_id)
    connection = await resolve_connection(db, user.id, conversation.org_connection_id)
    runtime = AgentRuntime(db, user, conversation, connection)
    return StreamingResponse(
        _stream(runtime.start(payload.message)),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/runs/{run_id}/resume")
async def resume_run(run_id: str, user: CurrentUser, db: DbSession) -> StreamingResponse:
    run = await db.get(AgentRun, run_id)
    if run is None or run.user_id != user.id:
        raise HTTPException(status_code=404, detail="Run not found")
    if run.state != AgentState.AWAITING_APPROVAL:
        raise HTTPException(
            status_code=409,
            detail=f"Run is in state {run.state.value}; only AWAITING_APPROVAL can resume.",
        )
    conversation = await owned_conversation(db, user.id, run.conversation_id)
    connection = await resolve_connection(db, user.id, run.org_connection_id)
    runtime = AgentRuntime(db, user, conversation, connection)
    return StreamingResponse(
        _stream(runtime.resume(run)),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/runs/{run_id}")
async def get_run(run_id: str, user: CurrentUser, db: DbSession) -> dict[str, Any]:
    run = await db.get(AgentRun, run_id)
    if run is None or run.user_id != user.id:
        raise HTTPException(status_code=404, detail="Run not found")
    return {
        "id": run.id,
        "conversation_id": run.conversation_id,
        "state": run.state.value,
        "steps_used": run.steps_used,
        "max_steps": run.max_steps,
        "model": run.model,
        "input_tokens": run.input_tokens,
        "output_tokens": run.output_tokens,
        "duration_ms": run.duration_ms,
        "error": run.error,
        "final_text": run.final_text,
        "pending_approval_ids": run.pending_approval_ids or [],
        "created_at": run.created_at.isoformat(),
    }


@router.get("/tools")
async def list_tools() -> dict[str, Any]:
    registry = build_registry()
    return {"count": len(registry.all()), "tools": registry.catalog()}
