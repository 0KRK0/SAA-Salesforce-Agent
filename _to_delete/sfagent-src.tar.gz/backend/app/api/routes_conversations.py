"""Conversation CRUD."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from app.models import AgentRun, Conversation, Message, OrgConnection
from app.security.auth import CurrentUser, DbSession

router = APIRouter(prefix="/conversations", tags=["conversations"])


class ConversationCreate(BaseModel):
    title: str = "New conversation"
    org_connection_id: str | None = None


class ConversationPatch(BaseModel):
    title: str | None = None
    org_connection_id: str | None = None


class ConversationOut(BaseModel):
    id: str
    title: str
    org_connection_id: str | None
    created_at: str
    updated_at: str


def _out(c: Conversation) -> ConversationOut:
    return ConversationOut(
        id=c.id,
        title=c.title,
        org_connection_id=c.org_connection_id,
        created_at=c.created_at.isoformat(),
        updated_at=c.updated_at.isoformat(),
    )


@router.get("", response_model=list[ConversationOut])
async def list_conversations(user: CurrentUser, db: DbSession) -> list[ConversationOut]:
    rows = (
        (
            await db.execute(
                select(Conversation)
                .where(Conversation.user_id == user.id)
                .order_by(Conversation.updated_at.desc())
                .limit(100)
            )
        )
        .scalars()
        .all()
    )
    return [_out(c) for c in rows]


@router.post("", response_model=ConversationOut)
async def create_conversation(
    payload: ConversationCreate, user: CurrentUser, db: DbSession
) -> ConversationOut:
    if payload.org_connection_id:
        conn = await db.get(OrgConnection, payload.org_connection_id)
        if conn is None or conn.user_id != user.id:
            raise HTTPException(status_code=404, detail="Connection not found")
    conversation = Conversation(
        user_id=user.id, title=payload.title, org_connection_id=payload.org_connection_id
    )
    db.add(conversation)
    await db.commit()
    return _out(conversation)


@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: str, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    conversation = await _owned(db, user.id, conversation_id)
    messages = (
        (
            await db.execute(
                select(Message)
                .where(Message.conversation_id == conversation_id)
                .order_by(Message.created_at)
            )
        )
        .scalars()
        .all()
    )
    runs = (
        (
            await db.execute(
                select(AgentRun)
                .where(AgentRun.conversation_id == conversation_id)
                .order_by(AgentRun.created_at)
            )
        )
        .scalars()
        .all()
    )
    return {
        "conversation": _out(conversation).model_dump(),
        "messages": [
            {
                "id": m.id,
                "role": m.role,
                "text": m.text,
                "agent_run_id": m.agent_run_id,
                "created_at": m.created_at.isoformat(),
            }
            for m in messages
        ],
        "runs": [
            {
                "id": r.id,
                "state": r.state.value,
                "steps_used": r.steps_used,
                "error": r.error,
                "input_tokens": r.input_tokens,
                "output_tokens": r.output_tokens,
                "created_at": r.created_at.isoformat(),
            }
            for r in runs
        ],
    }


@router.patch("/{conversation_id}", response_model=ConversationOut)
async def patch_conversation(
    conversation_id: str, payload: ConversationPatch, user: CurrentUser, db: DbSession
) -> ConversationOut:
    conversation = await _owned(db, user.id, conversation_id)
    if payload.title is not None:
        conversation.title = payload.title
    if payload.org_connection_id is not None:
        conn = await db.get(OrgConnection, payload.org_connection_id)
        if conn is None or conn.user_id != user.id:
            raise HTTPException(status_code=404, detail="Connection not found")
        conversation.org_connection_id = payload.org_connection_id
    await db.commit()
    return _out(conversation)


@router.delete("/{conversation_id}")
async def delete_conversation(
    conversation_id: str, user: CurrentUser, db: DbSession
) -> dict[str, bool]:
    conversation = await _owned(db, user.id, conversation_id)
    await db.delete(conversation)
    await db.commit()
    return {"success": True}


async def _owned(db: Any, user_id: str, conversation_id: str) -> Conversation:
    conversation = await db.get(Conversation, conversation_id)
    if conversation is None or conversation.user_id != user_id:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation
