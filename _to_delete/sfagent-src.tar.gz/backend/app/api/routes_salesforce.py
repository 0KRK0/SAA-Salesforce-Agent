"""Salesforce org connection endpoints (OAuth 2.0 web-server flow)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlalchemy import select

from app.config import settings
from app.models import OrgConnection
from app.observability.logging import get_logger
from app.salesforce.client import SalesforceClient
from app.salesforce.errors import SalesforceError
from app.salesforce.oauth import (
    build_authorize_url,
    consume_state,
    exchange_code,
    fetch_identity,
    upsert_connection,
)
from app.security.auth import CurrentUser, DbSession, decode_session_token

router = APIRouter(prefix="/salesforce", tags=["salesforce"])
log = get_logger("api.salesforce")


class ConnectionOut(BaseModel):
    id: str
    sf_org_id: str
    username: str
    instance_url: str
    org_type: str
    is_sandbox: bool
    api_version: str
    is_active: bool
    last_validated_at: str | None = None

    @classmethod
    def of(cls, c: OrgConnection) -> ConnectionOut:
        return cls(
            id=c.id,
            sf_org_id=c.sf_org_id,
            username=c.username,
            instance_url=c.instance_url,
            org_type=c.org_type,
            is_sandbox=c.is_sandbox,
            api_version=c.api_version,
            is_active=c.is_active,
            last_validated_at=c.last_validated_at.isoformat() if c.last_validated_at else None,
        )


@router.get("/config")
async def config() -> dict[str, Any]:
    return {
        "configured": settings.salesforce_configured,
        "login_url": settings.salesforce_login_url,
        "redirect_uri": settings.salesforce_redirect_uri,
        "api_version": settings.salesforce_api_version,
        "scopes": settings.sf_scope_list,
        "allow_production_mutations": settings.allow_production_mutations,
        "setup_hint": (
            None
            if settings.salesforce_configured
            else "Create a Salesforce Connected App and set SALESFORCE_CLIENT_ID, "
            "SALESFORCE_CLIENT_SECRET and SALESFORCE_REDIRECT_URI in backend/.env"
        ),
    }


@router.get("/connections", response_model=list[ConnectionOut])
async def list_connections(user: CurrentUser, db: DbSession) -> list[ConnectionOut]:
    rows = (
        (
            await db.execute(
                select(OrgConnection)
                .where(OrgConnection.user_id == user.id)
                .order_by(OrgConnection.created_at.desc())
            )
        )
        .scalars()
        .all()
    )
    return [ConnectionOut.of(c) for c in rows]


@router.post("/oauth/start")
async def oauth_start(
    user: CurrentUser,
    db: DbSession,
    sandbox: bool = Query(False, description="Use test.salesforce.com"),
    login_url: str | None = Query(None, description="Custom My Domain login URL"),
) -> dict[str, str]:
    try:
        url = await build_authorize_url(db, user.id, sandbox=sandbox, login_url=login_url)
    except SalesforceError as exc:
        raise HTTPException(status_code=400, detail=exc.to_dict()) from exc
    await db.commit()
    return {"authorize_url": url}


@router.get("/oauth/callback")
async def oauth_callback(
    db: DbSession,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
) -> RedirectResponse:
    front = settings.frontend_base_url.rstrip("/")
    if error:
        log.warning("salesforce.oauth_denied", error=error)
        return RedirectResponse(f"{front}/connections?error={error}")
    if not code or not state:
        return RedirectResponse(f"{front}/connections?error=missing_code")

    try:
        state_row = await consume_state(db, state)
        bundle = await exchange_code(state_row.login_url, code, state_row.code_verifier)
        identity = await fetch_identity(bundle)
        conn = await upsert_connection(
            db, state_row.user_id, bundle, identity, state_row.login_url
        )
        async with SalesforceClient(conn, db) as sf:
            await sf.validate()
        await db.commit()
    except SalesforceError as exc:
        await db.rollback()
        log.error("salesforce.oauth_failed", error=exc.message)
        return RedirectResponse(f"{front}/connections?error={exc.error_type}")

    return RedirectResponse(f"{front}/connections?connected={conn.id}")


@router.post("/connections/{connection_id}/validate")
async def validate_connection(
    connection_id: str, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    conn = await _owned(db, user.id, connection_id)
    try:
        async with SalesforceClient(conn, db) as sf:
            info = await sf.validate()
        await db.commit()
    except SalesforceError as exc:
        conn.is_active = False
        await db.commit()
        raise HTTPException(status_code=400, detail=exc.to_dict()) from exc
    return {"success": True, "connection": ConnectionOut.of(conn).model_dump(), "org": info}


@router.delete("/connections/{connection_id}")
async def disconnect(connection_id: str, user: CurrentUser, db: DbSession) -> dict[str, bool]:
    conn = await _owned(db, user.id, connection_id)
    await db.delete(conn)
    await db.commit()
    return {"success": True}


async def _owned(db: Any, user_id: str, connection_id: str) -> OrgConnection:
    conn = await db.get(OrgConnection, connection_id)
    if conn is None or conn.user_id != user_id:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


async def resolve_connection(
    db: Any, user_id: str, connection_id: str | None
) -> OrgConnection | None:
    """Tenant-isolated lookup used by the agent routes."""
    if not connection_id:
        return None
    conn = await db.get(OrgConnection, connection_id)
    if conn is None or conn.user_id != user_id or not conn.is_active:
        return None
    return conn


__all__ = ["ConnectionOut", "decode_session_token", "resolve_connection", "router"]
