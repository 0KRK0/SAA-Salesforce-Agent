"""Audit, tool-execution and deployment history."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import select

from app.models import AuditLog, Deployment, ToolExecution
from app.security.auth import CurrentUser, DbSession

router = APIRouter(tags=["audit"])


@router.get("/audit")
async def list_audit(
    user: CurrentUser,
    db: DbSession,
    conversation_id: str | None = Query(None),
    agent_run_id: str | None = Query(None),
    action: str | None = Query(None),
    limit: int = Query(100, le=500),
) -> dict[str, Any]:
    stmt = select(AuditLog).where(AuditLog.user_id == user.id)
    if conversation_id:
        stmt = stmt.where(AuditLog.conversation_id == conversation_id)
    if agent_run_id:
        stmt = stmt.where(AuditLog.agent_run_id == agent_run_id)
    if action:
        stmt = stmt.where(AuditLog.action == action)
    rows = (
        (await db.execute(stmt.order_by(AuditLog.created_at.desc()).limit(limit)))
        .scalars()
        .all()
    )
    return {
        "count": len(rows),
        "entries": [
            {
                "id": r.id,
                "action": r.action,
                "tool_name": r.tool_name,
                "arguments": r.arguments,
                "result_summary": r.result_summary,
                "salesforce_object": r.salesforce_object,
                "record_ids": r.record_ids,
                "before_values": r.before_values,
                "after_values": r.after_values,
                "risk_level": r.risk_level.value if r.risk_level else None,
                "approval_state": r.approval_state.value if r.approval_state else None,
                "execution_state": r.execution_state.value if r.execution_state else None,
                "deployment_id": r.deployment_id,
                "outcome": r.outcome,
                "error": r.error,
                "conversation_id": r.conversation_id,
                "agent_run_id": r.agent_run_id,
                "sf_org_id": r.sf_org_id,
                "created_at": r.created_at.isoformat(),
            }
            for r in rows
        ],
    }


@router.get("/tool-executions")
async def list_tool_executions(
    user: CurrentUser,
    db: DbSession,
    agent_run_id: str | None = Query(None),
    limit: int = Query(100, le=500),
) -> dict[str, Any]:
    stmt = select(ToolExecution).where(ToolExecution.user_id == user.id)
    if agent_run_id:
        stmt = stmt.where(ToolExecution.agent_run_id == agent_run_id)
    rows = (
        (await db.execute(stmt.order_by(ToolExecution.created_at.desc()).limit(limit)))
        .scalars()
        .all()
    )
    return {
        "count": len(rows),
        "executions": [
            {
                "id": r.id,
                "agent_run_id": r.agent_run_id,
                "tool_name": r.tool_name,
                "arguments": r.arguments,
                "result": r.result,
                "risk_level": r.risk_level.value,
                "approval_state": r.approval_state.value,
                "execution_state": r.execution_state.value,
                "salesforce_object": r.salesforce_object,
                "record_ids": r.record_ids,
                "error_type": r.error_type,
                "error_message": r.error_message,
                "duration_ms": r.duration_ms,
                "created_at": r.created_at.isoformat(),
            }
            for r in rows
        ],
    }


@router.get("/deployments")
async def list_deployments(
    user: CurrentUser, db: DbSession, limit: int = Query(50, le=200)
) -> dict[str, Any]:
    rows = (
        (
            await db.execute(
                select(Deployment)
                .where(Deployment.user_id == user.id)
                .order_by(Deployment.created_at.desc())
                .limit(limit)
            )
        )
        .scalars()
        .all()
    )
    return {"count": len(rows), "deployments": [_deployment(r) for r in rows]}


@router.get("/deployments/{deployment_id}")
async def get_deployment(
    deployment_id: str, user: CurrentUser, db: DbSession
) -> dict[str, Any]:
    row = await db.get(Deployment, deployment_id)
    if row is None or row.user_id != user.id:
        raise HTTPException(status_code=404, detail="Deployment not found")
    return _deployment(row)


def _deployment(r: Deployment) -> dict[str, Any]:
    return {
        "id": r.id,
        "agent_run_id": r.agent_run_id,
        "salesforce_deploy_id": r.salesforce_deploy_id,
        "check_only": r.check_only,
        "status": r.status,
        "components_total": r.components_total,
        "components_failed": r.components_failed,
        "tests_total": r.tests_total,
        "tests_failed": r.tests_failed,
        "package_manifest": r.package_manifest,
        "errors": r.errors,
        "verified": r.verified,
        "created_at": r.created_at.isoformat(),
    }
