"""The agent runtime.

Claude is the reasoning engine; this module is the machine that keeps it safe:
state machine, tool dispatch, deterministic validation, risk classification,
human approval gating, idempotency, verification, audit and step limits.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agent.claude import ClaudeCallError, ClaudeNotConfigured, call_model
from app.agent.context import compact_transcript, serialize_tool_result
from app.agent.prompts import build_system_prompt
from app.config import settings
from app.models import (
    AgentRun,
    AgentState,
    Approval,
    ApprovalState,
    AuditLog,
    Conversation,
    ExecutionState,
    Message,
    OrgConnection,
    RiskLevel,
    ToolExecution,
    User,
)
from app.observability.logging import get_logger, redact, run_id_var
from app.risk.engine import OrgContext, classify
from app.salesforce.client import SalesforceClient
from app.salesforce.errors import SalesforceError
from app.tools.base import Tool, ToolContext, ToolValidationError
from app.tools.registry import build_registry

log = get_logger("agent.runtime")

Event = dict[str, Any]


def _canonical(args: dict[str, Any]) -> str:
    return json.dumps(args, sort_keys=True, default=str)


def idempotency_key(run_id: str, tool_name: str, args: dict[str, Any]) -> str:
    return hashlib.sha256(f"{run_id}|{tool_name}|{_canonical(args)}".encode()).hexdigest()


class AgentRuntime:
    def __init__(
        self,
        db: AsyncSession,
        user: User,
        conversation: Conversation,
        connection: OrgConnection | None,
    ) -> None:
        self.db = db
        self.user = user
        self.conversation = conversation
        self.connection = connection
        self.registry = build_registry()
        self._queue: asyncio.Queue[Event | None] = asyncio.Queue()
        self.sf: SalesforceClient | None = None

    # ------------------------------------------------------------ event plumbing
    async def emit(self, type_: str, data: dict[str, Any] | None = None) -> None:
        await self._queue.put({"type": type_, "data": data or {}})

    async def _drain(self, task: asyncio.Task) -> AsyncIterator[Event]:
        while True:
            event = await self._queue.get()
            if event is None:
                break
            yield event
        exc = task.exception() if task.done() else None
        if exc:  # pragma: no cover - surfaced as an error event already
            raise exc

    # ----------------------------------------------------------------- lifecycle
    async def start(self, user_text: str) -> AsyncIterator[Event]:
        run = AgentRun(
            conversation_id=self.conversation.id,
            user_id=self.user.id,
            org_connection_id=self.connection.id if self.connection else None,
            state=AgentState.UNDERSTANDING,
            user_request=user_text,
            max_steps=settings.max_agent_steps,
            model=settings.claude_model,
            transcript=[],
        )
        self.db.add(run)
        self.db.add(
            Message(
                conversation_id=self.conversation.id,
                role="user",
                text=user_text,
                agent_run_id=run.id,
            )
        )
        if self.conversation.title == "New conversation":
            self.conversation.title = user_text.strip()[:120] or "New conversation"
        await self.db.commit()

        history = await self._load_history(exclude_run=run.id)
        messages = [*history, {"role": "user", "content": user_text}]
        task = asyncio.create_task(self._guarded(run, messages))
        async for event in self._drain(task):
            yield event

    async def resume(self, run: AgentRun) -> AsyncIterator[Event]:
        task = asyncio.create_task(self._guarded_resume(run))
        async for event in self._drain(task):
            yield event

    async def _guarded(self, run: AgentRun, messages: list[dict[str, Any]]) -> None:
        try:
            await self._loop(run, messages)
        except Exception as exc:
            await self._fail(run, exc)
        finally:
            await self._queue.put(None)

    async def _guarded_resume(self, run: AgentRun) -> None:
        try:
            messages = await self._rebuild_after_approval(run)
            if messages is not None:
                await self._loop(run, messages)
        except Exception as exc:
            await self._fail(run, exc)
        finally:
            await self._queue.put(None)

    async def _fail(self, run: AgentRun, exc: Exception) -> None:
        message = str(exc)
        if isinstance(exc, ClaudeNotConfigured):
            message = (
                "The agent is not configured: ANTHROPIC_API_KEY is missing. "
                "Set it in the backend .env and restart."
            )
        elif isinstance(exc, ClaudeCallError):
            message = f"Claude call failed: {exc}"
        log.error("agent.run_failed", error=message, exc_info=True)
        run.state = AgentState.FAILED
        run.error = message
        await self.db.commit()
        await self._audit(run, action="agent.run_failed", outcome="error", error=message)
        await self.emit("state", {"state": AgentState.FAILED.value})
        await self.emit("error", {"message": message})

    # -------------------------------------------------------------------- history
    async def _load_history(self, exclude_run: str | None = None) -> list[dict[str, Any]]:
        rows = (
            (
                await self.db.execute(
                    select(Message)
                    .where(Message.conversation_id == self.conversation.id)
                    .order_by(Message.created_at)
                )
            )
            .scalars()
            .all()
        )
        messages: list[dict[str, Any]] = []
        for row in rows:
            if exclude_run and row.agent_run_id == exclude_run:
                continue
            if row.role not in {"user", "assistant"}:
                continue
            messages.append({"role": row.role, "content": row.text})
        return compact_transcript(messages)

    # ----------------------------------------------------------------- main loop
    async def _loop(self, run: AgentRun, messages: list[dict[str, Any]]) -> None:
        run_id_var.set(run.id)
        started = time.perf_counter()
        await self.emit("run.started", {"run_id": run.id, "model": run.model})

        org_ctx = OrgContext(
            is_sandbox=bool(self.connection.is_sandbox) if self.connection else True,
            org_type=self.connection.org_type if self.connection else "unknown",
            allow_production_mutations=settings.allow_production_mutations,
        )
        system = build_system_prompt(
            {
                "sf_org_id": self.connection.sf_org_id,
                "instance_url": self.connection.instance_url,
                "org_type": self.connection.org_type,
                "is_sandbox": self.connection.is_sandbox,
                "api_version": self.connection.api_version,
                "username": self.connection.username,
            }
            if self.connection
            else None
        )
        tools = self.registry.anthropic_schemas()

        async with self._salesforce() as sf:
            self.sf = sf
            while True:
                if run.steps_used >= run.max_steps:
                    await self._halt_max_steps(run, messages)
                    return

                run.steps_used += 1
                await self._set_state(
                    run, AgentState.PLANNING if run.steps_used > 1 else AgentState.UNDERSTANDING
                )
                response = await call_model(system, compact_transcript(messages), tools)
                run.input_tokens += response.input_tokens
                run.output_tokens += response.output_tokens
                run.model = response.model
                messages.append({"role": "assistant", "content": response.content})

                if response.text:
                    await self.emit("assistant.text", {"text": response.text})

                if response.stop_reason != "tool_use":
                    await self._complete(run, messages, response.text, started)
                    return

                await self._set_state(run, AgentState.EXECUTING)
                results, paused = await self._dispatch(run, response.tool_uses, org_ctx)

                if paused:
                    run.transcript = messages
                    run.pending_tool_results = results
                    run.state = AgentState.AWAITING_APPROVAL
                    run.duration_ms = (time.perf_counter() - started) * 1000
                    await self.db.commit()
                    await self.emit("state", {"state": AgentState.AWAITING_APPROVAL.value})
                    await self.emit(
                        "run.paused",
                        {"run_id": run.id, "approval_ids": run.pending_approval_ids or []},
                    )
                    return

                messages.append({"role": "user", "content": results})
                run.transcript = messages
                await self.db.commit()

    @asynccontextmanager
    async def _salesforce(self) -> AsyncIterator[SalesforceClient | None]:
        if self.connection is None:
            yield None
            return
        async with SalesforceClient(self.connection, self.db) as client:
            yield client

    # ------------------------------------------------------------------ dispatch
    async def _dispatch(
        self, run: AgentRun, tool_uses: list[dict[str, Any]], org_ctx: OrgContext
    ) -> tuple[list[dict[str, Any]], bool]:
        results: list[dict[str, Any]] = []
        pending_approvals: list[str] = []

        for block in tool_uses:
            name = block.get("name", "")
            args = block.get("input") or {}
            tool = self.registry.get(name)
            if tool is None:
                results.append(
                    self._tool_result(
                        block["id"],
                        {
                            "success": False,
                            "error_type": "UNKNOWN_TOOL",
                            "message": f"No tool named '{name}' is registered.",
                            "retryable": False,
                        },
                        is_error=True,
                    )
                )
                continue

            await self.emit(
                "tool.started",
                {
                    "tool": name,
                    "tool_use_id": block["id"],
                    "arguments": redact(args),
                    "risk": tool.risk.value,
                },
            )

            ctx = self._tool_context(run)

            # 1. deterministic validation
            try:
                if tool.validate:
                    await tool.validate(ctx, args)
            except ToolValidationError as exc:
                payload = exc.to_dict()
                await self._record_execution(
                    run, tool, block, args, payload, ExecutionState.FAILED, RiskLevel.LOW,
                    ApprovalState.NOT_REQUIRED, 0.0, error=exc.message,
                )
                await self.emit("tool.failed", {"tool": name, "error": exc.message})
                results.append(self._tool_result(block["id"], payload, is_error=True))
                continue
            except SalesforceError as exc:
                payload = exc.to_dict()
                await self.emit("tool.failed", {"tool": name, "error": exc.message})
                results.append(self._tool_result(block["id"], payload, is_error=True))
                continue

            # 2. risk classification (outside the model)
            decision = classify(name, args, tool.risk, org_ctx, tool.requires_approval)
            if decision.blocked:
                payload = {
                    "success": False,
                    "error_type": "BLOCKED_BY_POLICY",
                    "message": decision.blocked_reason,
                    "retryable": False,
                    "risk": decision.to_dict(),
                    "suggested_action": (
                        "Explain the policy to the user; do not attempt a workaround."
                    ),
                }
                await self._record_execution(
                    run, tool, block, args, payload, ExecutionState.SKIPPED, decision.risk,
                    ApprovalState.NOT_REQUIRED, 0.0, error=decision.blocked_reason,
                )
                await self.emit("tool.blocked", {"tool": name, "reason": decision.blocked_reason})
                results.append(self._tool_result(block["id"], payload, is_error=True))
                continue

            # 3. approval gate
            if decision.requires_approval:
                plan = await tool.plan(ctx, args) if tool.plan else {"title": name}
                approval = Approval(
                    agent_run_id=run.id,
                    conversation_id=self.conversation.id,
                    user_id=self.user.id,
                    org_connection_id=self.connection.id if self.connection else None,
                    tool_name=name,
                    tool_use_id=block["id"],
                    arguments=args,
                    plan=plan | {"risk": decision.to_dict()},
                    risk_level=decision.risk,
                    state=ApprovalState.PENDING,
                )
                self.db.add(approval)
                await self.db.flush()
                pending_approvals.append(approval.id)
                await self._audit(
                    run,
                    action="approval.requested",
                    tool_name=name,
                    arguments=args,
                    risk=decision.risk,
                    approval_state=ApprovalState.PENDING,
                    execution_state=ExecutionState.PROPOSED,
                )
                await self.emit(
                    "approval.requested",
                    {
                        "approval_id": approval.id,
                        "tool": name,
                        "risk": decision.risk.value,
                        "plan": plan,
                        "reasons": decision.reasons,
                    },
                )
                continue

            # 4. execute
            payload = await self._execute_tool(run, tool, block, args, decision)
            results.append(
                self._tool_result(block["id"], payload, is_error=not payload.get("success", False))
            )

        if pending_approvals:
            run.pending_approval_ids = pending_approvals
            await self.db.flush()
            return results, True
        return results, False

    def _tool_context(self, run: AgentRun) -> ToolContext:
        return ToolContext(
            user=self.user,
            db=self.db,
            connection=self.connection,
            sf=self.sf,
            agent_run_id=run.id,
            conversation_id=self.conversation.id,
            emit=self.emit,
        )

    async def _execute_tool(
        self,
        run: AgentRun,
        tool: Tool,
        block: dict[str, Any],
        args: dict[str, Any],
        decision: Any,
        approval_state: ApprovalState = ApprovalState.NOT_REQUIRED,
    ) -> dict[str, Any]:
        ctx = self._tool_context(run)
        key = idempotency_key(run.id, tool.name, args)

        # Idempotency: an identical mutation already succeeded in this run.
        if tool.mutating:
            prior = (
                await self.db.execute(
                    select(ToolExecution).where(
                        ToolExecution.agent_run_id == run.id,
                        ToolExecution.idempotency_key == key,
                        ToolExecution.execution_state == ExecutionState.SUCCEEDED,
                    )
                )
            ).scalar_one_or_none()
            if prior is not None:
                await self.emit("tool.idempotent_hit", {"tool": tool.name})
                return (prior.result or {}) | {
                    "idempotent_replay": True,
                    "note": (
                        "This exact mutation already succeeded earlier in this run; "
                        "the previous result is returned instead of executing again."
                    ),
                }

        t0 = time.perf_counter()
        try:
            payload = await asyncio.wait_for(
                tool.execute(ctx, args), timeout=settings.tool_timeout_seconds
            )
        except TimeoutError:
            payload = {
                "success": False,
                "error_type": "TOOL_TIMEOUT",
                "message": f"{tool.name} exceeded {settings.tool_timeout_seconds:.0f}s.",
                "retryable": True,
                "suggested_action": (
                    "The operation may still be running in Salesforce. Re-inspect state "
                    "before retrying."
                ),
            }
        except SalesforceError as exc:
            payload = exc.to_dict()
        except ToolValidationError as exc:
            payload = exc.to_dict()
        except Exception as exc:
            log.error("tool.unhandled_error", tool=tool.name, exc_info=True)
            payload = {
                "success": False,
                "error_type": "TOOL_INTERNAL_ERROR",
                "message": f"{type(exc).__name__}: {exc}",
                "retryable": False,
                "suggested_action": "Report the failure to the user; do not retry blindly.",
            }
        duration = (time.perf_counter() - t0) * 1000

        # 5. verification against real Salesforce state
        verification: dict[str, Any] | None = None
        if payload.get("success") and tool.verify:
            await self._set_state(run, AgentState.VERIFYING)
            await self.emit("tool.verifying", {"tool": tool.name})
            try:
                verification = await tool.verify(ctx, args, payload)
            except Exception as exc:
                verification = {"verified": False, "reason": f"Verification failed: {exc}"}
            payload["verification"] = verification
            payload["verified"] = bool(verification.get("verified"))
            if not payload["verified"]:
                payload["success"] = False
                payload.setdefault("error_type", "VERIFICATION_FAILED")
                payload.setdefault(
                    "message",
                    "The operation was accepted by Salesforce but could not be verified.",
                )
                payload["suggested_action"] = (
                    "Do not report this as complete. Re-inspect the org and tell the user "
                    "what was and was not confirmed."
                )

        state = ExecutionState.SUCCEEDED if payload.get("success") else ExecutionState.FAILED
        await self._record_execution(
            run, tool, block, args, payload, state, decision.risk, approval_state, duration,
            idem_key=key if tool.mutating else None,
            error=None if payload.get("success") else payload.get("message"),
        )
        await self.emit(
            "tool.finished" if payload.get("success") else "tool.failed",
            {
                "tool": tool.name,
                "tool_use_id": block["id"],
                "success": bool(payload.get("success")),
                "verified": payload.get("verified"),
                "duration_ms": round(duration, 1),
                "summary": _summarize(payload),
            },
        )
        return payload

    # ----------------------------------------------------------------- approvals
    async def _rebuild_after_approval(self, run: AgentRun) -> list[dict[str, Any]] | None:
        approvals = (
            (
                await self.db.execute(
                    select(Approval).where(Approval.agent_run_id == run.id)
                )
            )
            .scalars()
            .all()
        )
        pending_ids = set(run.pending_approval_ids or [])
        relevant = [a for a in approvals if a.id in pending_ids]
        undecided = [a for a in relevant if a.state == ApprovalState.PENDING]
        if undecided:
            await self.emit(
                "run.waiting",
                {"approval_ids": [a.id for a in undecided], "message": "Approval still pending."},
            )
            return None

        messages = list(run.transcript or [])
        results = list(run.pending_tool_results or [])
        org_ctx = OrgContext(
            is_sandbox=bool(self.connection.is_sandbox) if self.connection else True,
            org_type=self.connection.org_type if self.connection else "unknown",
            allow_production_mutations=settings.allow_production_mutations,
        )

        async with self._salesforce() as sf:
            self.sf = sf
            for approval in relevant:
                tool = self.registry.get(approval.tool_name)
                if tool is None:  # pragma: no cover - defensive
                    continue
                if approval.state != ApprovalState.APPROVED:
                    payload = {
                        "success": False,
                        "error_type": "APPROVAL_REJECTED",
                        "message": (
                            f"A human rejected the proposed {approval.tool_name} change."
                            + (f" Note: {approval.decision_note}" if approval.decision_note else "")
                        ),
                        "retryable": False,
                        "suggested_action": (
                            "Do not retry. Acknowledge the rejection and ask what the user "
                            "would like instead."
                        ),
                    }
                    await self._audit(
                        run,
                        action="approval.rejected",
                        tool_name=approval.tool_name,
                        arguments=approval.arguments,
                        risk=approval.risk_level,
                        approval_state=ApprovalState.REJECTED,
                        execution_state=ExecutionState.SKIPPED,
                    )
                    await self.emit("approval.rejected", {"approval_id": approval.id})
                    results.append(
                        self._tool_result(approval.tool_use_id, payload, is_error=True)
                    )
                    continue

                args = approval.modified_arguments or approval.arguments or {}
                await self.emit(
                    "approval.approved",
                    {"approval_id": approval.id, "tool": approval.tool_name},
                )
                # Re-validate: the org may have changed while awaiting the human.
                ctx = self._tool_context(run)
                try:
                    if tool.validate:
                        await tool.validate(ctx, args)
                except ToolValidationError as exc:
                    payload = exc.to_dict()
                    payload["message"] = (
                        f"Re-validation after approval failed: {exc.message}"
                    )
                    results.append(
                        self._tool_result(approval.tool_use_id, payload, is_error=True)
                    )
                    continue

                decision = classify(
                    approval.tool_name, args, tool.risk, org_ctx, tool.requires_approval
                )
                block = {"id": approval.tool_use_id, "name": approval.tool_name, "input": args}
                payload = await self._execute_tool(
                    run, tool, block, args, decision, ApprovalState.APPROVED
                )
                results.append(
                    self._tool_result(
                        approval.tool_use_id,
                        payload,
                        is_error=not payload.get("success", False),
                    )
                )

        messages.append({"role": "user", "content": results})
        run.pending_tool_results = None
        run.pending_approval_ids = None
        run.state = AgentState.EXECUTING
        run.transcript = messages
        await self.db.commit()
        return messages

    # ------------------------------------------------------------------ helpers
    def _tool_result(
        self, tool_use_id: str, payload: dict[str, Any], is_error: bool = False
    ) -> dict[str, Any]:
        return {
            "type": "tool_result",
            "tool_use_id": tool_use_id,
            "is_error": is_error,
            "content": serialize_tool_result(payload),
        }

    async def _set_state(self, run: AgentRun, state: AgentState) -> None:
        if run.state != state:
            run.state = state
            await self.emit("state", {"state": state.value})

    async def _halt_max_steps(self, run: AgentRun, messages: list[dict[str, Any]]) -> None:
        message = (
            f"Stopped after {run.max_steps} agent steps without completing the request. "
            "This is a safety limit against runaway tool loops; the operation needs "
            "manual review before continuing."
        )
        run.state = AgentState.FAILED
        run.error = message
        run.final_text = message
        run.transcript = messages
        self.db.add(
            Message(
                conversation_id=self.conversation.id,
                role="assistant",
                text=message,
                agent_run_id=run.id,
            )
        )
        await self.db.commit()
        await self._audit(run, action="agent.max_steps_exceeded", outcome="halted")
        await self.emit("state", {"state": AgentState.FAILED.value})
        await self.emit("run.halted", {"reason": "max_steps_exceeded", "message": message})

    async def _complete(
        self, run: AgentRun, messages: list[dict[str, Any]], text: str, started: float
    ) -> None:
        run.state = AgentState.COMPLETED
        run.final_text = text
        run.transcript = messages
        run.duration_ms = (time.perf_counter() - started) * 1000
        self.db.add(
            Message(
                conversation_id=self.conversation.id,
                role="assistant",
                text=text,
                agent_run_id=run.id,
            )
        )
        await self.db.commit()
        await self._audit(run, action="agent.run_completed", outcome="ok")
        await self.emit("state", {"state": AgentState.COMPLETED.value})
        await self.emit(
            "run.completed",
            {
                "run_id": run.id,
                "steps": run.steps_used,
                "input_tokens": run.input_tokens,
                "output_tokens": run.output_tokens,
                "duration_ms": round(run.duration_ms, 1),
            },
        )

    async def _record_execution(
        self,
        run: AgentRun,
        tool: Tool,
        block: dict[str, Any],
        args: dict[str, Any],
        payload: dict[str, Any],
        state: ExecutionState,
        risk: RiskLevel,
        approval_state: ApprovalState,
        duration_ms: float,
        idem_key: str | None = None,
        error: str | None = None,
    ) -> ToolExecution:
        record_ids = []
        if payload.get("record_id"):
            record_ids = [payload["record_id"]]
        execution = ToolExecution(
            agent_run_id=run.id,
            conversation_id=self.conversation.id,
            user_id=self.user.id,
            org_connection_id=self.connection.id if self.connection else None,
            tool_name=tool.name,
            tool_use_id=block.get("id", ""),
            arguments=redact(args),
            result=redact(_summarize(payload, full=True)),
            risk_level=risk,
            approval_state=approval_state,
            execution_state=state,
            idempotency_key=idem_key,
            salesforce_object=str(args.get("object") or "") or None,
            record_ids=record_ids or None,
            error_type=payload.get("error_type"),
            error_message=error,
            duration_ms=duration_ms,
        )
        self.db.add(execution)
        await self.db.flush()
        await self._audit(
            run,
            action=tool.audit_action or f"tool.{tool.name}",
            tool_name=tool.name,
            arguments=args,
            result_summary=_summarize(payload),
            risk=risk,
            approval_state=approval_state,
            execution_state=state,
            tool_execution_id=execution.id,
            sobject=str(args.get("object") or "") or None,
            record_ids=record_ids or None,
            before=payload.get("before"),
            after=(payload.get("verification") or {}).get("after"),
            deployment_id=payload.get("deployment_id"),
            outcome="ok" if payload.get("success") else "error",
            error=error,
        )
        await self.db.commit()
        return execution

    async def _audit(
        self,
        run: AgentRun,
        *,
        action: str,
        tool_name: str | None = None,
        arguments: dict[str, Any] | None = None,
        result_summary: dict[str, Any] | None = None,
        risk: RiskLevel | None = None,
        approval_state: ApprovalState | None = None,
        execution_state: ExecutionState | None = None,
        tool_execution_id: str | None = None,
        sobject: str | None = None,
        record_ids: list[str] | None = None,
        before: dict[str, Any] | None = None,
        after: dict[str, Any] | None = None,
        deployment_id: str | None = None,
        outcome: str = "ok",
        error: str | None = None,
    ) -> None:
        self.db.add(
            AuditLog(
                user_id=self.user.id,
                org_connection_id=self.connection.id if self.connection else None,
                sf_org_id=self.connection.sf_org_id if self.connection else None,
                conversation_id=self.conversation.id,
                agent_run_id=run.id,
                tool_execution_id=tool_execution_id,
                action=action,
                tool_name=tool_name,
                arguments=redact(arguments) if arguments else None,
                result_summary=redact(result_summary) if result_summary else None,
                salesforce_object=sobject,
                record_ids=record_ids,
                before_values=before,
                after_values=after,
                risk_level=risk,
                approval_state=approval_state,
                execution_state=execution_state,
                deployment_id=deployment_id,
                outcome=outcome,
                error=error,
            )
        )
        await self.db.flush()


def _summarize(payload: dict[str, Any], full: bool = False) -> dict[str, Any]:
    """Audit/UI-safe summary: never store or display whole record dumps."""
    out = {
        k: v
        for k, v in payload.items()
        if k
        in {
            "success",
            "object",
            "field",
            "record_id",
            "count",
            "total_size",
            "deploy_id",
            "deployment_id",
            "status",
            "verified",
            "error_type",
            "message",
            "already_exists",
            "check_only",
        }
    }
    if full and payload.get("verification"):
        out["verification"] = payload["verification"]
    if payload.get("errors"):
        out["errors"] = payload["errors"][:5]
    return out


async def touch_conversation(db: AsyncSession, conversation: Conversation) -> None:
    conversation.updated_at = datetime.now(UTC)
    await db.commit()
