"""Deterministic risk classification and approval policy.

This layer sits OUTSIDE the model. Claude can propose anything; only this
engine decides whether an action may execute, and only an explicit human
approval record can unblock a HIGH-risk action.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.config import settings
from app.models import RiskLevel


@dataclass
class RiskDecision:
    risk: RiskLevel
    requires_approval: bool
    reasons: list[str]
    blocked: bool = False
    blocked_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "risk": self.risk.value,
            "requires_approval": self.requires_approval,
            "reasons": self.reasons,
            "blocked": self.blocked,
            "blocked_reason": self.blocked_reason,
        }


# Objects whose modification is treated as security-sensitive.
SECURITY_OBJECTS = {
    "user",
    "profile",
    "permissionset",
    "permissionsetassignment",
    "userrole",
    "groupmember",
    "objectpermissions",
    "fieldpermissions",
    "sharingrules",
    "networkmember",
}


@dataclass
class OrgContext:
    is_sandbox: bool = True
    org_type: str = "unknown"
    allow_production_mutations: bool = False


def classify(
    tool_name: str,
    arguments: dict[str, Any],
    base_risk: RiskLevel,
    org: OrgContext,
    tool_requires_approval: bool,
) -> RiskDecision:
    reasons: list[str] = []
    risk = base_risk
    requires_approval = tool_requires_approval

    obj = str(arguments.get("object") or arguments.get("sobject") or "").lower()
    is_mutation = base_risk in (RiskLevel.MEDIUM, RiskLevel.HIGH)

    # --- object sensitivity escalation ---
    if obj in SECURITY_OBJECTS and is_mutation:
        risk = RiskLevel.HIGH
        requires_approval = True
        reasons.append(f"'{obj}' is a security/permission object.")

    # --- destructive intent escalation ---
    if tool_name.startswith("delete") or arguments.get("hard_delete"):
        risk = RiskLevel.HIGH
        requires_approval = True
        reasons.append("Deletion is irreversible.")

    # --- bulk blast radius ---
    record_ids = arguments.get("record_ids")
    if isinstance(record_ids, list) and len(record_ids) > 20:
        risk = RiskLevel.HIGH
        requires_approval = True
        reasons.append(f"Affects {len(record_ids)} records in one operation.")

    # --- production posture ---
    if is_mutation and not org.is_sandbox:
        requires_approval = True
        reasons.append("Target org is not a sandbox.")
        if risk == RiskLevel.MEDIUM:
            risk = RiskLevel.HIGH
        if tool_name in {"create_field", "deploy_metadata"} and not (
            org.allow_production_mutations or settings.allow_production_mutations
        ):
            return RiskDecision(
                risk=RiskLevel.HIGH,
                requires_approval=True,
                reasons=[*reasons, "Metadata changes to production are disabled."],
                blocked=True,
                blocked_reason=(
                    "Metadata deployment to a non-sandbox org is disabled by policy. "
                    "Set ALLOW_PRODUCTION_MUTATIONS=true (and re-deploy) to permit it, "
                    "or target a sandbox."
                ),
            )

    # --- metadata deployments that skip validation ---
    if tool_name == "deploy_metadata" and arguments.get("check_only") is False:
        requires_approval = True
        reasons.append("Real (non-validation) metadata deployment.")

    if not reasons:
        reasons.append(f"Base risk for {tool_name} is {risk.value}.")

    return RiskDecision(risk=risk, requires_approval=requires_approval, reasons=reasons)
