"""Persistence model: users, org connections, conversations, agent runs,
tool executions, approvals, audit log, deployments.

Design notes
------------
* Salesforce tokens are stored encrypted (see app.security.crypto).
* Every mutating operation is represented by a ToolExecution row plus an
  AuditLog row; nothing mutates Salesforce without leaving a trail.
* Tenant isolation key is (user_id, org_connection_id) on every row that can
  reach Salesforce data.
"""

from __future__ import annotations

import enum
from datetime import UTC, datetime

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base
from app.observability.logging import new_id


def utcnow() -> datetime:
    return datetime.now(UTC)


class RiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class ApprovalState(str, enum.Enum):
    NOT_REQUIRED = "NOT_REQUIRED"
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class ExecutionState(str, enum.Enum):
    PLANNED = "PLANNED"
    PROPOSED = "PROPOSED"
    APPROVED = "APPROVED"
    EXECUTING = "EXECUTING"
    SUCCEEDED = "SUCCEEDED"
    PARTIALLY_SUCCEEDED = "PARTIALLY_SUCCEEDED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class AgentState(str, enum.Enum):
    IDLE = "IDLE"
    UNDERSTANDING = "UNDERSTANDING"
    INSPECTING = "INSPECTING"
    PLANNING = "PLANNING"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    EXECUTING = "EXECUTING"
    VALIDATING = "VALIDATING"
    VERIFYING = "VERIFYING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("usr"))
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(200), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    connections: Mapped[list[OrgConnection]] = relationship(back_populates="user")


class OrgConnection(Base):
    """A connected Salesforce organization (OAuth)."""

    __tablename__ = "org_connections"
    __table_args__ = (
        UniqueConstraint("user_id", "sf_org_id", name="uq_user_org"),
        Index("ix_org_conn_user", "user_id"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("org"))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)

    sf_org_id: Mapped[str] = mapped_column(String(32), index=True)
    sf_user_id: Mapped[str] = mapped_column(String(32), default="")
    username: Mapped[str] = mapped_column(String(320), default="")
    instance_url: Mapped[str] = mapped_column(String(512))
    login_url: Mapped[str] = mapped_column(String(512), default="")
    is_sandbox: Mapped[bool] = mapped_column(Boolean, default=False)
    org_type: Mapped[str] = mapped_column(String(64), default="unknown")
    api_version: Mapped[str] = mapped_column(String(16), default="62.0")

    access_token_enc: Mapped[str] = mapped_column(Text)
    refresh_token_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    token_fingerprint: Mapped[str] = mapped_column(String(32), default="")
    scopes: Mapped[str] = mapped_column(String(512), default="")

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_validated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    user: Mapped[User] = relationship(back_populates="connections")


class OAuthState(Base):
    """Short-lived CSRF/PKCE state for the OAuth handshake."""

    __tablename__ = "oauth_states"

    state: Mapped[str] = mapped_column(String(128), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    code_verifier: Mapped[str] = mapped_column(String(256))
    login_url: Mapped[str] = mapped_column(String(512))
    redirect_after: Mapped[str] = mapped_column(String(512), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Conversation(Base):
    __tablename__ = "conversations"
    __table_args__ = (Index("ix_conv_user_created", "user_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("conv"))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    org_connection_id: Mapped[str | None] = mapped_column(
        ForeignKey("org_connections.id"), nullable=True, index=True
    )
    title: Mapped[str] = mapped_column(String(300), default="New conversation")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    messages: Mapped[list[Message]] = relationship(
        back_populates="conversation", order_by="Message.created_at"
    )


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (Index("ix_msg_conv_created", "conversation_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("msg"))
    conversation_id: Mapped[str] = mapped_column(ForeignKey("conversations.id"), index=True)
    # 'user' | 'assistant' — tool traffic lives in ToolExecution, and the raw
    # Anthropic content blocks are kept in `blocks` for faithful replay.
    role: Mapped[str] = mapped_column(String(20))
    text: Mapped[str] = mapped_column(Text, default="")
    blocks: Mapped[list | None] = mapped_column(JSON, nullable=True)
    agent_run_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    conversation: Mapped[Conversation] = relationship(back_populates="messages")


class AgentRun(Base):
    __tablename__ = "agent_runs"
    __table_args__ = (Index("ix_run_conv", "conversation_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("run"))
    conversation_id: Mapped[str] = mapped_column(ForeignKey("conversations.id"), index=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    org_connection_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)

    state: Mapped[AgentState] = mapped_column(Enum(AgentState), default=AgentState.IDLE)
    user_request: Mapped[str] = mapped_column(Text, default="")
    steps_used: Mapped[int] = mapped_column(Integer, default=0)
    max_steps: Mapped[int] = mapped_column(Integer, default=20)
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    model: Mapped[str] = mapped_column(String(128), default="")
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    final_text: Mapped[str] = mapped_column(Text, default="")
    duration_ms: Mapped[float] = mapped_column(Float, default=0.0)
    # Anthropic message list, persisted so an interrupted run can resume.
    transcript: Mapped[list | None] = mapped_column(JSON, nullable=True)
    # tool_result blocks already computed while the run waits for approval.
    pending_tool_results: Mapped[list | None] = mapped_column(JSON, nullable=True)
    # Approval ids that must be decided before the run can continue.
    pending_approval_ids: Mapped[list | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )


class ToolExecution(Base):
    __tablename__ = "tool_executions"
    __table_args__ = (Index("ix_tool_run", "agent_run_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("tex"))
    agent_run_id: Mapped[str] = mapped_column(String(64), index=True)
    conversation_id: Mapped[str] = mapped_column(String(64), index=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    org_connection_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    tool_name: Mapped[str] = mapped_column(String(128), index=True)
    tool_use_id: Mapped[str] = mapped_column(String(128), default="")
    arguments: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    risk_level: Mapped[RiskLevel] = mapped_column(Enum(RiskLevel), default=RiskLevel.LOW)
    approval_state: Mapped[ApprovalState] = mapped_column(
        Enum(ApprovalState), default=ApprovalState.NOT_REQUIRED
    )
    execution_state: Mapped[ExecutionState] = mapped_column(
        Enum(ExecutionState), default=ExecutionState.PLANNED
    )
    idempotency_key: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    salesforce_object: Mapped[str | None] = mapped_column(String(128), nullable=True)
    record_ids: Mapped[list | None] = mapped_column(JSON, nullable=True)
    error_type: Mapped[str | None] = mapped_column(String(128), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    duration_ms: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Approval(Base):
    """Explicit human-in-the-loop decision record. Approval is NEVER inferred
    from conversational text; only an explicit API action writes here."""

    __tablename__ = "approvals"
    __table_args__ = (Index("ix_appr_user_state", "user_id", "state"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("apr"))
    agent_run_id: Mapped[str] = mapped_column(String(64), index=True)
    conversation_id: Mapped[str] = mapped_column(String(64), index=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    org_connection_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    tool_name: Mapped[str] = mapped_column(String(128))
    tool_use_id: Mapped[str] = mapped_column(String(128), default="")
    arguments: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    # Human-readable change plan rendered for the approval card.
    plan: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    risk_level: Mapped[RiskLevel] = mapped_column(Enum(RiskLevel), default=RiskLevel.MEDIUM)
    state: Mapped[ApprovalState] = mapped_column(Enum(ApprovalState), default=ApprovalState.PENDING)
    decided_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    # If the human edited arguments before approving.
    modified_arguments: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Deployment(Base):
    __tablename__ = "deployments"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("dep"))
    agent_run_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    org_connection_id: Mapped[str] = mapped_column(String(64), index=True)

    salesforce_deploy_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    check_only: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(64), default="Queued")
    components_total: Mapped[int] = mapped_column(Integer, default=0)
    components_failed: Mapped[int] = mapped_column(Integer, default=0)
    tests_total: Mapped[int] = mapped_column(Integer, default=0)
    tests_failed: Mapped[int] = mapped_column(Integer, default=0)
    package_manifest: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    errors: Mapped[list | None] = mapped_column(JSON, nullable=True)
    duration_ms: Mapped[float] = mapped_column(Float, default=0.0)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_user_created", "user_id", "created_at"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("aud"))
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    org_connection_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    sf_org_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    conversation_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    agent_run_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    tool_execution_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    request_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    action: Mapped[str] = mapped_column(String(128), index=True)
    tool_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    arguments: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    result_summary: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    salesforce_object: Mapped[str | None] = mapped_column(String(128), nullable=True)
    record_ids: Mapped[list | None] = mapped_column(JSON, nullable=True)
    before_values: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after_values: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    risk_level: Mapped[RiskLevel | None] = mapped_column(Enum(RiskLevel), nullable=True)
    approval_state: Mapped[ApprovalState | None] = mapped_column(
        Enum(ApprovalState), nullable=True
    )
    execution_state: Mapped[ExecutionState | None] = mapped_column(
        Enum(ExecutionState), nullable=True
    )
    deployment_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    outcome: Mapped[str] = mapped_column(String(64), default="ok")
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
