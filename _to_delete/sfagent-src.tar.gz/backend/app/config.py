"""Environment-driven application configuration.

No secret is ever hardcoded. Everything comes from the environment (or a
local .env file, which must never be committed).
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    # --- App ---
    app_name: str = "Salesforce AI Agent"
    environment: Literal["local", "dev", "staging", "production"] = "local"
    log_level: str = "INFO"
    api_prefix: str = "/api"
    cors_origins: str = "http://localhost:3000"

    # --- Database ---
    database_url: str = "sqlite+aiosqlite:///./sfagent.db"

    # --- Session / auth ---
    session_secret: str = "dev-only-insecure-session-secret-change-me"  # noqa: S105
    session_ttl_seconds: int = 60 * 60 * 12

    # --- Secret encryption (Fernet key, urlsafe base64 32 bytes) ---
    # Generate with:
    #   python -c "from cryptography.fernet import Fernet; \
    #              print(Fernet.generate_key().decode())"
    encryption_key: str = ""

    # --- Anthropic / Claude ---
    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-5"
    claude_max_tokens: int = 4096
    claude_temperature: float | None = None
    claude_timeout_seconds: float = 120.0
    claude_max_retries: int = 3

    # --- Agent runtime ---
    max_agent_steps: int = 20
    max_tool_result_chars: int = 20_000
    max_query_rows: int = 500
    default_query_limit: int = 200
    tool_timeout_seconds: float = 90.0

    # --- Salesforce OAuth ---
    salesforce_client_id: str = ""
    salesforce_client_secret: str = ""
    salesforce_redirect_uri: str = "http://localhost:8000/api/salesforce/oauth/callback"
    salesforce_login_url: str = "https://login.salesforce.com"
    salesforce_api_version: str = "62.0"
    salesforce_scopes: str = "api refresh_token offline_access"
    # Refuse metadata mutations against non-sandbox orgs unless explicitly allowed.
    allow_production_mutations: bool = False

    # --- Frontend ---
    frontend_base_url: str = "http://localhost:3000"

    @field_validator("cors_origins")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def sf_scope_list(self) -> list[str]:
        return [s.strip() for s in self.salesforce_scopes.split() if s.strip()]

    @property
    def claude_configured(self) -> bool:
        return bool(self.anthropic_api_key)

    @property
    def salesforce_configured(self) -> bool:
        return bool(self.salesforce_client_id and self.salesforce_redirect_uri)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
