"""FastAPI application entrypoint."""

from __future__ import annotations

import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import (
    routes_agent,
    routes_approvals,
    routes_audit,
    routes_auth,
    routes_conversations,
    routes_salesforce,
)
from app.config import settings
from app.db import init_db
from app.observability.logging import configure_logging, get_logger, request_id_var
from app.salesforce.errors import SalesforceError
from app.tools.base import ToolValidationError
from app.tools.registry import build_registry

configure_logging(settings.log_level)
log = get_logger("app")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    await init_db()
    registry = build_registry()
    log.info(
        "app.startup",
        environment=settings.environment,
        tools=registry.names(),
        claude_configured=settings.claude_configured,
        salesforce_configured=settings.salesforce_configured,
        model=settings.claude_model,
    )
    yield
    log.info("app.shutdown")


app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def request_context(request: Request, call_next: Any) -> Any:
    rid = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:16]
    token = request_id_var.set(rid)
    try:
        response = await call_next(request)
    finally:
        request_id_var.reset(token)
    response.headers["X-Request-ID"] = rid
    return response


@app.exception_handler(SalesforceError)
async def salesforce_error_handler(_: Request, exc: SalesforceError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code or 400, content=exc.to_dict())


@app.exception_handler(ToolValidationError)
async def tool_validation_handler(_: Request, exc: ToolValidationError) -> JSONResponse:
    return JSONResponse(status_code=400, content=exc.to_dict())


@app.get("/health")
async def health() -> dict[str, Any]:
    registry = build_registry()
    return {
        "status": "ok",
        "environment": settings.environment,
        "claude_configured": settings.claude_configured,
        "salesforce_configured": settings.salesforce_configured,
        "encryption_configured": bool(settings.encryption_key),
        "model": settings.claude_model,
        "max_agent_steps": settings.max_agent_steps,
        "tools": registry.names(),
    }


for router in (
    routes_auth.router,
    routes_salesforce.router,
    routes_conversations.router,
    routes_agent.router,
    routes_approvals.router,
    routes_audit.router,
):
    app.include_router(router, prefix=settings.api_prefix)
