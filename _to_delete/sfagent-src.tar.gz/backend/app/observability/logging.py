"""Structured logging + request/run correlation ids."""

from __future__ import annotations

import contextvars
import logging
import sys
import time
import uuid
from typing import Any

import structlog

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "request_id", default=""
)
run_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("run_id", default="")

_SECRET_KEYS = {
    "access_token",
    "refresh_token",
    "client_secret",
    "authorization",
    "api_key",
    "anthropic_api_key",
    "password",
    "session",
    "encryption_key",
}


def redact(value: Any, _depth: int = 0) -> Any:
    """Recursively redact known secret-bearing keys."""
    if _depth > 8:
        return "<truncated>"
    if isinstance(value, dict):
        return {
            k: ("<redacted>" if k.lower() in _SECRET_KEYS else redact(v, _depth + 1))
            for k, v in value.items()
        }
    if isinstance(value, list | tuple):
        return [redact(v, _depth + 1) for v in value]
    return value


def _add_context(_logger: Any, _name: str, event_dict: dict) -> dict:
    rid = request_id_var.get()
    run = run_id_var.get()
    if rid:
        event_dict.setdefault("request_id", rid)
    if run:
        event_dict.setdefault("agent_run_id", run)
    return event_dict


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        format="%(message)s", stream=sys.stdout, level=getattr(logging, level.upper(), 20)
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            _add_context,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), 20)
        ),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "app") -> Any:
    return structlog.get_logger(name)


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:24]}"


class Timer:
    """Context manager yielding elapsed milliseconds."""

    def __init__(self) -> None:
        self.ms: float = 0.0
        self._t0 = 0.0

    def __enter__(self) -> Timer:
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.ms = (time.perf_counter() - self._t0) * 1000.0
