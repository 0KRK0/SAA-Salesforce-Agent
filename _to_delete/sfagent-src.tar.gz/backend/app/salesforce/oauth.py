"""Salesforce OAuth 2.0 web-server flow with PKCE + refresh handling.

Tokens are encrypted at rest and are never placed in prompts or tool results.
"""

from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models import OAuthState, OrgConnection
from app.observability.logging import get_logger
from app.salesforce.errors import SalesforceAuthError, from_response
from app.security.crypto import encrypt, fingerprint, random_token

log = get_logger("salesforce.oauth")

SANDBOX_LOGIN = "https://test.salesforce.com"
PROD_LOGIN = "https://login.salesforce.com"


def _pkce_pair() -> tuple[str, str]:
    verifier = random_token(48)
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        .rstrip(b"=")
        .decode()
    )
    return verifier, challenge


@dataclass
class TokenBundle:
    access_token: str
    refresh_token: str | None
    instance_url: str
    id_url: str
    issued_at: datetime
    scopes: str
    raw: dict[str, Any]


async def build_authorize_url(
    session: AsyncSession,
    user_id: str,
    sandbox: bool = False,
    login_url: str | None = None,
    redirect_after: str = "",
) -> str:
    if not settings.salesforce_configured:
        raise SalesforceAuthError(
            error_type="CONFIG_MISSING",
            message="SALESFORCE_CLIENT_ID / SALESFORCE_REDIRECT_URI are not configured.",
            suggested_action=(
                "Create a Salesforce Connected App and set SALESFORCE_CLIENT_ID, "
                "SALESFORCE_CLIENT_SECRET and SALESFORCE_REDIRECT_URI in .env"
            ),
        )
    base = login_url or (SANDBOX_LOGIN if sandbox else settings.salesforce_login_url)
    verifier, challenge = _pkce_pair()
    state = random_token(24)
    session.add(
        OAuthState(
            state=state,
            user_id=user_id,
            code_verifier=verifier,
            login_url=base,
            redirect_after=redirect_after,
        )
    )
    await session.flush()
    params = {
        "response_type": "code",
        "client_id": settings.salesforce_client_id,
        "redirect_uri": settings.salesforce_redirect_uri,
        "scope": " ".join(settings.sf_scope_list),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "prompt": "login",
    }
    return f"{base.rstrip('/')}/services/oauth2/authorize?{urlencode(params)}"


async def _token_request(login_url: str, data: dict[str, str]) -> TokenBundle:
    url = f"{login_url.rstrip('/')}/services/oauth2/token"
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            url, data=data, headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
    if resp.status_code != 200:
        try:
            payload = resp.json()
        except Exception:
            payload = resp.text
        err = from_response(resp.status_code, payload)
        raise SalesforceAuthError(
            error_type=err.error_type or "OAUTH_FAILED",
            message=err.message,
            status_code=resp.status_code,
            likely_cause="The OAuth token endpoint rejected the request.",
            suggested_action=(
                "Verify the Connected App consumer key/secret, the callback URL, and "
                "that the user is allowed to access the app."
            ),
        )
    body = resp.json()
    return TokenBundle(
        access_token=body["access_token"],
        refresh_token=body.get("refresh_token"),
        instance_url=body["instance_url"],
        id_url=body.get("id", ""),
        issued_at=datetime.now(UTC),
        scopes=body.get("scope", ""),
        raw=body,
    )


async def exchange_code(login_url: str, code: str, code_verifier: str) -> TokenBundle:
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "client_id": settings.salesforce_client_id,
        "redirect_uri": settings.salesforce_redirect_uri,
        "code_verifier": code_verifier,
    }
    if settings.salesforce_client_secret:
        data["client_secret"] = settings.salesforce_client_secret
    return await _token_request(login_url, data)


async def refresh_access_token(login_url: str, refresh_token: str) -> TokenBundle:
    data = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": settings.salesforce_client_id,
    }
    if settings.salesforce_client_secret:
        data["client_secret"] = settings.salesforce_client_secret
    bundle = await _token_request(login_url, data)
    if not bundle.refresh_token:
        bundle.refresh_token = refresh_token
    return bundle


async def fetch_identity(bundle: TokenBundle) -> dict[str, Any]:
    if not bundle.id_url:
        return {}
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            bundle.id_url, headers={"Authorization": f"Bearer {bundle.access_token}"}
        )
    if resp.status_code != 200:
        return {}
    return resp.json()


async def consume_state(session: AsyncSession, state: str) -> OAuthState:
    row = await session.get(OAuthState, state)
    if row is None:
        raise SalesforceAuthError(
            error_type="INVALID_OAUTH_STATE",
            message="OAuth state is unknown or already used.",
            likely_cause="CSRF protection rejected the callback.",
            suggested_action="Restart the Salesforce connection flow.",
        )
    await session.delete(row)
    return row


async def upsert_connection(
    session: AsyncSession,
    user_id: str,
    bundle: TokenBundle,
    identity: dict[str, Any],
    login_url: str,
) -> OrgConnection:
    org_id = str(identity.get("organization_id") or "")[:18]
    if not org_id:
        # Fall back to the id URL shape: .../id/{orgId}/{userId}
        parts = bundle.id_url.rstrip("/").split("/")
        org_id = parts[-2] if len(parts) >= 2 else "unknown"
    sf_user_id = str(identity.get("user_id") or "")[:18]
    is_sandbox = login_url.rstrip("/") == SANDBOX_LOGIN or ".sandbox." in bundle.instance_url

    existing = (
        await session.execute(
            select(OrgConnection).where(
                OrgConnection.user_id == user_id, OrgConnection.sf_org_id == org_id
            )
        )
    ).scalar_one_or_none()

    conn = existing or OrgConnection(user_id=user_id, sf_org_id=org_id)
    conn.sf_user_id = sf_user_id
    conn.username = str(identity.get("username") or "")
    conn.instance_url = bundle.instance_url.rstrip("/")
    conn.login_url = login_url.rstrip("/")
    conn.is_sandbox = is_sandbox
    conn.org_type = "sandbox" if is_sandbox else "production"
    conn.api_version = settings.salesforce_api_version
    conn.access_token_enc = encrypt(bundle.access_token)
    conn.refresh_token_enc = encrypt(bundle.refresh_token) if bundle.refresh_token else None
    conn.token_issued_at = bundle.issued_at
    conn.token_fingerprint = fingerprint(bundle.access_token)
    conn.scopes = bundle.scopes
    conn.is_active = True
    conn.last_validated_at = datetime.now(UTC)
    if existing is None:
        session.add(conn)
    await session.flush()
    log.info(
        "salesforce.connected",
        org_connection_id=conn.id,
        sf_org_id=org_id,
        sandbox=is_sandbox,
    )
    return conn
