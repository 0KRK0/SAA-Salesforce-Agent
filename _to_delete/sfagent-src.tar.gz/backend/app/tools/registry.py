"""Central tool registry.

New Salesforce (or external-system) capabilities are added by registering a
Tool here; the agent runtime does not change.
"""

from __future__ import annotations

from collections.abc import Iterable

from app.tools.base import Tool


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> Tool:
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered")
        self._tools[tool.name] = tool
        return tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def require(self, name: str) -> Tool:
        tool = self._tools.get(name)
        if tool is None:
            raise KeyError(f"Unknown tool '{name}'")
        return tool

    def all(self) -> list[Tool]:
        return list(self._tools.values())

    def names(self) -> list[str]:
        return sorted(self._tools)

    def anthropic_schemas(self, only: Iterable[str] | None = None) -> list[dict]:
        allowed = set(only) if only else None
        return [
            t.anthropic_schema()
            for t in self._tools.values()
            if allowed is None or t.name in allowed
        ]

    def catalog(self) -> list[dict]:
        return [t.describe() for t in self._tools.values()]


registry = ToolRegistry()


def build_registry() -> ToolRegistry:
    """Import side-effect registration exactly once."""
    if registry.all():
        return registry
    from app.tools import (  # noqa: F401
        create_field,
        create_record,
        deploy_metadata,
        describe_object,
        query_salesforce,
        update_record,
    )

    return registry
