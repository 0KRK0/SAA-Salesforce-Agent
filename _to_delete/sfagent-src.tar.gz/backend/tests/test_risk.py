from app.models import RiskLevel
from app.risk.engine import OrgContext, classify

SANDBOX = OrgContext(is_sandbox=True, org_type="sandbox")
PRODUCTION = OrgContext(is_sandbox=False, org_type="Enterprise Edition")


def test_read_tool_is_low_and_needs_no_approval():
    d = classify("query_salesforce", {"soql": "SELECT Id FROM Account"}, RiskLevel.LOW, SANDBOX, False)
    assert d.risk is RiskLevel.LOW
    assert not d.requires_approval
    assert not d.blocked


def test_record_mutation_requires_approval():
    d = classify("create_record", {"object": "Account"}, RiskLevel.MEDIUM, SANDBOX, True)
    assert d.requires_approval


def test_security_object_escalates_to_high():
    d = classify("update_record", {"object": "PermissionSet"}, RiskLevel.MEDIUM, SANDBOX, True)
    assert d.risk is RiskLevel.HIGH
    assert d.requires_approval


def test_delete_is_high_risk():
    d = classify("delete_record", {"object": "Account"}, RiskLevel.MEDIUM, SANDBOX, False)
    assert d.risk is RiskLevel.HIGH
    assert d.requires_approval


def test_bulk_blast_radius_escalates():
    d = classify(
        "bulk_update", {"object": "Account", "record_ids": [str(i) for i in range(50)]},
        RiskLevel.MEDIUM, SANDBOX, True,
    )
    assert d.risk is RiskLevel.HIGH


def test_production_metadata_is_blocked_by_default():
    d = classify("create_field", {"object": "Account"}, RiskLevel.MEDIUM, PRODUCTION, True)
    assert d.blocked
    assert "production" in d.blocked_reason.lower() or "sandbox" in d.blocked_reason.lower()


def test_production_metadata_allowed_when_policy_permits():
    org = OrgContext(is_sandbox=False, org_type="Enterprise", allow_production_mutations=True)
    d = classify("create_field", {"object": "Account"}, RiskLevel.MEDIUM, org, True)
    assert not d.blocked
    assert d.requires_approval
    assert d.risk is RiskLevel.HIGH


def test_production_record_mutation_escalates_but_is_not_blocked():
    d = classify("update_record", {"object": "Account"}, RiskLevel.MEDIUM, PRODUCTION, True)
    assert not d.blocked
    assert d.risk is RiskLevel.HIGH
    assert d.requires_approval
