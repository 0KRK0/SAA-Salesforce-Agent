"""API-level tests (ASGI transport, no network)."""

from __future__ import annotations

import httpx
import pytest
import pytest_asyncio
from sqlalchemy import select

from app.db import get_session
from app.main import app
from app.models import AgentRun, AgentState, Approval, Conversation
from app.security.auth import create_session_token


@pytest_asyncio.fixture
async def client(db):
    async def _override():
        yield db

    app.dependency_overrides[get_session] = _override
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def auth(user):
    return {"Authorization": f"Bearer {create_session_token(user.id)}"}


async def test_health_lists_tools(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert "describe_object" in body["tools"]
    assert "create_field" in body["tools"]


async def test_tool_catalog_exposes_risk_metadata(client):
    body = (await client.get("/api/tools")).json()
    by_name = {t["name"]: t for t in body["tools"]}
    assert by_name["query_salesforce"]["risk"] == "LOW"
    assert by_name["query_salesforce"]["requires_approval"] is False
    assert by_name["deploy_metadata"]["risk"] == "HIGH"
    assert by_name["create_field"]["requires_approval"] is True


async def test_requires_authentication(client):
    assert (await client.get("/api/conversations")).status_code == 401


async def test_login_and_me(client):
    resp = await client.post(
        "/api/auth/login", json={"email": "person@example.com", "display_name": "Person"}
    )
    assert resp.status_code == 200
    me = await client.get("/api/auth/me")
    assert me.status_code == 200
    assert me.json()["email"] == "person@example.com"


async def test_conversation_crud(client, auth, db, connection):
    created = await client.post(
        "/api/conversations",
        json={"title": "Org cleanup", "org_connection_id": connection.id},
        headers=auth,
    )
    assert created.status_code == 200
    cid = created.json()["id"]

    listed = await client.get("/api/conversations", headers=auth)
    assert [c["id"] for c in listed.json()] == [cid]

    detail = await client.get(f"/api/conversations/{cid}", headers=auth)
    assert detail.json()["conversation"]["title"] == "Org cleanup"

    deleted = await client.delete(f"/api/conversations/{cid}", headers=auth)
    assert deleted.json() == {"success": True}


async def test_cannot_read_another_users_conversation(client, auth, db, user):
    from app.models import User

    other = User(email="other@example.com")
    db.add(other)
    await db.commit()
    conv = Conversation(user_id=other.id, title="theirs")
    db.add(conv)
    await db.commit()

    resp = await client.get(f"/api/conversations/{conv.id}", headers=auth)
    assert resp.status_code == 404


async def test_salesforce_config_endpoint(client):
    body = (await client.get("/api/salesforce/config")).json()
    assert body["configured"] is True
    assert body["api_version"]


async def test_approval_decision_flow(client, auth, db, user, conversation, connection):
    run = AgentRun(
        conversation_id=conversation.id,
        user_id=user.id,
        org_connection_id=connection.id,
        state=AgentState.AWAITING_APPROVAL,
    )
    db.add(run)
    await db.flush()
    approval = Approval(
        agent_run_id=run.id,
        conversation_id=conversation.id,
        user_id=user.id,
        org_connection_id=connection.id,
        tool_name="create_field",
        tool_use_id="toolu_1",
        arguments={"object": "Account"},
        plan={"title": "Create field"},
    )
    db.add(approval)
    run.pending_approval_ids = [approval.id]
    await db.commit()

    listed = await client.get("/api/approvals?state=PENDING", headers=auth)
    assert listed.json()["count"] == 1

    decided = await client.post(
        f"/api/approvals/{approval.id}/decision",
        json={"decision": "approve", "note": "ok in sandbox"},
        headers=auth,
    )
    body = decided.json()
    assert body["approval"]["state"] == "APPROVED"
    assert body["resume_ready"] is True

    again = await client.post(
        f"/api/approvals/{approval.id}/decision", json={"decision": "reject"}, headers=auth
    )
    assert again.status_code == 409

    audit = await client.get("/api/audit", headers=auth)
    assert any(e["action"] == "approval.approved" for e in audit.json()["entries"])


async def test_resume_rejects_run_not_awaiting_approval(client, auth, db, user, conversation):
    run = AgentRun(
        conversation_id=conversation.id, user_id=user.id, state=AgentState.COMPLETED
    )
    db.add(run)
    await db.commit()
    resp = await client.post(f"/api/runs/{run.id}/resume", headers=auth)
    assert resp.status_code == 409


async def test_message_endpoint_streams_agent_trace(
    client, auth, db, user, conversation, connection, monkeypatch, fake_sf
):
    from app.salesforce.client import SalesforceClient
    from tests.test_agent import ModelStub, final_text, tool_use

    stub = ModelStub(
        [
            tool_use("describe_object", {"object": "Account"}),
            final_text("Account has 4 fields."),
        ]
    )
    monkeypatch.setattr("app.agent.runtime.call_model", stub)
    http = fake_sf.client()
    monkeypatch.setattr(
        "app.agent.runtime.SalesforceClient",
        lambda connection, db=None, **_: SalesforceClient(connection, db, http=http),
    )

    resp = await client.post(
        f"/api/conversations/{conversation.id}/messages",
        json={"message": "Inspect the Account object"},
        headers=auth,
    )
    assert resp.status_code == 200
    body = resp.text
    assert "event: tool.started" in body
    assert "event: run.completed" in body
    assert "event: stream.end" in body

    runs = (await db.execute(select(AgentRun))).scalars().all()
    assert runs[0].state is AgentState.COMPLETED

    executions = await client.get(
        f"/api/tool-executions?agent_run_id={runs[0].id}", headers=auth
    )
    assert executions.json()["executions"][0]["tool_name"] == "describe_object"
