# Salesforce AI Agent

A Claude-powered autonomous agent that operates a real Salesforce organization
through natural language: inspect schema, query data, create and update records,
create custom fields, and deploy metadata — with a deterministic safety layer,
human approval for mutations, verification against real org state, and a full
audit trail.

This is an **agent runtime**, not a chatbot:

```
user request → understand → inspect org → plan → select tools → execute
   → observe → reason again → validate → approval (when required)
   → execute mutation → verify in Salesforce → report
```

Claude is the reasoning engine. This application is the runtime. Salesforce APIs
are the execution layer. Authorization, risk classification and approval live
**outside** the model and cannot be talked around.

---

## Status

| Capability | State |
|---|---|
| Salesforce OAuth 2.0 (PKCE) + encrypted token storage + refresh | Implemented |
| `describe_object` (REST describe) | Implemented |
| `query_salesforce` (SOQL, validated, paginated, Bulk API 2.0 option) | Implemented |
| `create_record` / `update_record` (schema-validated, verified) | Implemented |
| `create_field` (Metadata API deploy + verify) | Implemented |
| `deploy_metadata` (package deploy, validation runs, Apex test levels) | Implemented |
| Risk engine, approval gate, audit log, idempotency, step caps | Implemented |
| Agent console (chat, execution trace, approval cards, audit) | Implemented |
| Flow / Apex / data-quality / org-audit agents | Not built — designed for (see `docs/architecture.md`) |

Nothing in this repository fakes a Salesforce call. Every tool talks to a real
Salesforce API; the only doubles are in `backend/tests/`, which are explicitly
test fixtures.

---

## Architecture

```
frontend (Next.js)  ──HTTP/SSE──►  backend (FastAPI)
                                       │
                                       ├── agent runtime (state machine, step cap)
                                       │      └── Claude (tool use)
                                       ├── tool registry ── tools ──► Salesforce
                                       │                              REST / SOQL
                                       │                              Metadata API
                                       │                              Tooling / Bulk
                                       ├── risk engine (deterministic)
                                       ├── approval store (human-in-the-loop)
                                       └── audit log + deployments (Postgres/SQLite)
```

Details: [`docs/architecture.md`](docs/architecture.md) ·
[`docs/tools.md`](docs/tools.md) · [`docs/salesforce.md`](docs/salesforce.md) ·
[`docs/security.md`](docs/security.md) · [`docs/development.md`](docs/development.md)

---

## Setup

### 1. Salesforce Connected App

In your Salesforce **sandbox** (Setup → App Manager → New Connected App):

* Enable OAuth Settings
* Callback URL: `http://localhost:8000/api/salesforce/oauth/callback`
* Scopes: `Manage user data via APIs (api)`, `Perform requests at any time (refresh_token, offline_access)`
* Require PKCE: enabled (recommended)
* After saving, copy the **Consumer Key** and **Consumer Secret**
* Under Manage → Edit Policies, set *Permitted Users* appropriately

Metadata deployments require the user's profile to have **Modify All Data** or
**Customize Application**.

### 2. Configuration

```bash
cp .env.example backend/.env
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# paste into ENCRYPTION_KEY
```

Fill in `ANTHROPIC_API_KEY`, `SALESFORCE_CLIENT_ID`, `SALESFORCE_CLIENT_SECRET`.
`CLAUDE_MODEL` is configuration — set it to the model you want to run; the code
never hardcodes a model name.

### 3. Run it

**Local (no Docker):**

```bash
cd backend
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --port 8000

cd ../frontend
npm install
npm run dev            # http://localhost:3000
```

**Docker:**

```bash
cp .env.example .env   # fill it in
docker compose up --build
```

`GET http://localhost:8000/health` reports which parts are configured.

---

## First run — the vertical slice

1. Open http://localhost:3000, sign in with your email (local identity layer).
2. **Salesforce connection → Connect sandbox**, complete the OAuth flow.
3. Ask: **"Inspect the Account object."**
   → agent calls `describe_object`, returns the real schema.
4. Ask: **"Find the 10 newest Accounts."**
   → agent builds SOQL, the validator enforces read-only + LIMIT, records come back.
5. Ask: **"Create a Customer Tier picklist on Account with Enterprise, SMB and Startup."**
   → agent inspects `Account`, checks whether the field exists, generates metadata,
   shows a change plan, **waits for your approval**, deploys via the Metadata API,
   polls the deployment, re-describes the object, and only then reports success.

Nothing in step 5 is executed by the model saying "approved" — approval is a
recorded decision made through the UI/API.

---

## Testing

```bash
cd backend
python -m pytest -q          # 69 tests: unit, tool, agent, API
python -m ruff check .
```

Covers SOQL validation, metadata generation/escaping, the risk engine, every
tool's validation path, agent tool selection, the approval gate ("sounds good"
never approves), production blocking, prompt-injection framing, max-step halting
and the HTTP/SSE surface.

Integration against a real org is manual and sandbox-first — see
[`docs/development.md`](docs/development.md).

---

## Environment variables

See [`.env.example`](.env.example). Summary:

| Variable | Purpose |
|---|---|
| `ANTHROPIC_API_KEY`, `CLAUDE_MODEL`, `CLAUDE_MAX_TOKENS` | Claude access + model selection |
| `SALESFORCE_CLIENT_ID/_SECRET/_REDIRECT_URI` | Connected App |
| `SALESFORCE_API_VERSION`, `SALESFORCE_SCOPES` | API surface |
| `ENCRYPTION_KEY` | Fernet key encrypting OAuth tokens at rest (required) |
| `SESSION_SECRET` | Signs application session JWTs |
| `DATABASE_URL` | SQLite locally, Postgres in Docker |
| `MAX_AGENT_STEPS`, `MAX_TOOL_RESULT_CHARS`, `MAX_QUERY_ROWS` | Cost + blast-radius control |
| `ALLOW_PRODUCTION_MUTATIONS` | Must be true before metadata can be deployed to a non-sandbox org |

Secrets are never committed, never logged (see `redact()` in
`app/observability/logging.py`) and never sent to Claude.

---

## Security posture

* Tokens encrypted at rest (Fernet), refreshed server-side, never in prompts.
* Tenant isolation: every query is scoped by `user_id`; a record id supplied by
  the model is verified against the user's own connection before use.
* SOQL is parsed and constrained: SELECT-only, mandatory LIMIT, row caps.
* Salesforce data reaching the model is wrapped in explicit
  `BEGIN/END_UNTRUSTED_SALESFORCE_DATA` markers and the system prompt treats it
  as inert content.
* Risk engine escalates on security objects, deletions, bulk operations and
  non-sandbox orgs; HIGH-risk actions cannot execute without a stored approval.
* Everything is audited: user, org, tool, arguments, sanitized result, risk,
  approval state, execution state, before/after values, deployment id.

Full detail: [`docs/security.md`](docs/security.md).

---

## Known limitations

* Identity is a local email + signed session; no SSO/SCIM (deliberately out of MVP scope).
* Field-level security is only granted for profiles you name explicitly in `create_field`.
* `deploy_metadata` deploys source you supply; there is no repo/retrieve sync yet.
* No Flow, Apex, report, permission or duplicate-analysis tools yet — the
  registry is built so they can be added without touching the runtime.
* Approval expiry, multi-approver policy and role-based authorization are not implemented.
* Bulk write operations (bulk update/delete) are not exposed as tools; only Bulk
  API *query* is used, for large extracts.
