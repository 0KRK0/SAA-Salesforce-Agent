# Salesforce integration

## Connected App

Setup → App Manager → **New Connected App** (or *New External Client App*):

| Setting | Value |
|---|---|
| Enable OAuth Settings | yes |
| Callback URL | `http://localhost:8000/api/salesforce/oauth/callback` |
| Selected scopes | `api`, `refresh_token, offline_access` |
| Require PKCE | recommended (the client always sends S256) |
| Require secret for Web Server Flow | either; the secret is sent when configured |

Copy the **Consumer Key** → `SALESFORCE_CLIENT_ID`, **Consumer Secret** →
`SALESFORCE_CLIENT_SECRET`.

Permissions the connected Salesforce user needs:

* API Enabled (all tools)
* object/field CRUD + FLS for the data you want the agent to touch
* **Customize Application** or **Modify All Data** for `create_field` /
  `deploy_metadata`

## OAuth flow

`POST /api/salesforce/oauth/start?sandbox=true` → authorize URL (PKCE verifier
and CSRF state stored server-side) → user consents → Salesforce redirects to
`/api/salesforce/oauth/callback` → code exchanged for tokens → identity fetched
→ `OrgConnection` upserted with tokens **encrypted** (Fernet) → connection
validated with `/limits` + an `Organization` query → redirect back to the console.

Sandbox is detected from the login host (`test.salesforce.com`) and the
`Organization.IsSandbox` field, and drives the risk engine.

Access tokens are refreshed automatically on `401 INVALID_SESSION_ID` and the
new token is re-encrypted in place; if there is no refresh token the user is
told to reconnect.

## APIs used

| API | Where | Why |
|---|---|---|
| REST `sobjects/{X}/describe` | `client.describe` | schema of record |
| REST `query` / `queryMore` | `client.query_all_pages` | SOQL with pagination |
| REST `sobjects/{X}` POST/PATCH/GET | record tools | create/update/verify |
| REST `composite` | available in `client.composite` | batched calls |
| Tooling API `query`, `executeAnonymous` | `client.tooling_*` | ApexClass/Flow metadata |
| Bulk API 2.0 query jobs | `client.bulk_query` | large extracts without loading them into the model |
| Metadata API `deploy` / `checkDeployStatus` (SOAP) | `metadata.MetadataClient` | field creation and package deployment |

API version comes from `SALESFORCE_API_VERSION` (default `62.0`) and is stored
per connection.

`Sforce-Limit-Info` is parsed on every call so daily API consumption is
observable in the structured logs.

## Metadata deployment details

The package is built in memory:

```
package.xml                     <- generated from the manifest
objects/Account.object          <- <CustomObject><fields>…</fields></CustomObject>
profiles/Admin.profile          <- optional fieldPermissions (FLS)
```

zipped, base64-encoded and sent as a SOAP `deploy()` call to
`/services/Soap/m/{version}` with the session id in `SessionHeader`. The client
polls `checkDeployStatus(includeDetails=true)` with backoff until `done`, then
parses `componentFailures` and Apex test `failures` into structured records.

Timeout produces `METADATA_DEPLOY_TIMEOUT` **with the deploy id**, because the
deployment is still running in Salesforce — the agent is told to report that
rather than to retry.

XML responses are parsed with `defusedxml` (XXE/entity-expansion safe) and every
value written into XML is escaped.

## Sandbox first

`ALLOW_PRODUCTION_MUTATIONS=false` (default) blocks `create_field` and
`deploy_metadata` against any non-sandbox org — before the tool runs, not inside
the model. Record mutations against production are permitted but escalated to
HIGH risk and always require approval.

## Not yet integrated

Flow/Apex authoring, `retrieve()`, destructive changes, report metadata,
permission analysis, bulk write jobs, and duplicate-rule inspection. The client
and registry are built so these are additive.
