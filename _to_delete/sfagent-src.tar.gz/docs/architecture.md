# Architecture

## Layers

```
┌──────────────────────────────────────────────────────────────┐
│ frontend/ (Next.js 15, App Router, TypeScript)               │
│  chat · execution trace · approval cards · connections · audit│
└───────────────┬──────────────────────────────────────────────┘
                │ HTTP + SSE (POST streams; EventSource cannot POST)
┌───────────────▼──────────────────────────────────────────────┐
│ backend/app (FastAPI, async)                                 │
│                                                              │
│  api/          routes: auth, salesforce, conversations,      │
│                agent (SSE), approvals, audit                 │
│  agent/        runtime.py  ← the machine                     │
│                claude.py   ← Anthropic wrapper (model = config)│
│                prompts.py  ← system policy                   │
│                context.py  ← truncation + trust boundary      │
│  tools/        registry.py + one module per capability        │
│  risk/         engine.py — deterministic, outside the model   │
│  salesforce/   client.py (REST/SOQL/Composite/Tooling/Bulk)   │
│                metadata.py (Metadata API SOAP deploy)         │
│                oauth.py, soql.py, errors.py                   │
│  security/     crypto.py (Fernet at rest), auth.py (sessions) │
│  observability/logging.py (structlog + redaction + ids)       │
│  models.py     users, org_connections, conversations, messages,│
│                agent_runs, tool_executions, approvals,        │
│                deployments, audit_logs                        │
└───────────────┬──────────────────────────────────────────────┘
                │ HTTPS
        Salesforce REST · SOQL · Metadata API · Tooling API · Bulk API 2.0
```

## The agent loop

`AgentRuntime._loop` (backend/app/agent/runtime.py):

1. Persist the user message, open an `AgentRun`, emit `run.started`.
2. Call Claude with the tool registry's schemas and the compacted transcript.
3. `stop_reason != tool_use` → finish, persist the assistant message, `COMPLETED`.
4. Otherwise dispatch each `tool_use` block:
   1. **Resolve** the tool in the registry (unknown → structured error back to the model).
   2. **Validate** deterministically (`tool.validate`) — schema and org-state checks.
   3. **Classify risk** (`risk/engine.py`) using tool metadata + arguments + org posture.
   4. **Blocked?** → structured `BLOCKED_BY_POLICY` result, `SKIPPED` execution row.
   5. **Approval required?** → build the change plan, insert a `PENDING` approval,
      emit `approval.requested`, and pause the run (`AWAITING_APPROVAL`) with the
      transcript and any already-computed tool results persisted.
   6. **Otherwise execute** with a timeout, then **verify** against real org state.
   7. Record `ToolExecution` + `AuditLog`, emit `tool.finished` / `tool.failed`.
5. Append the tool results as a user turn and loop, until `max_steps`.

`AgentRuntime.resume` reconstructs the paused turn: it fills a `tool_result`
block for every pending approval — approved ones are **re-validated** (the org
may have changed while the human deliberated) and executed, rejected ones return
an `APPROVAL_REJECTED` result — then re-enters the loop.

## State machine

```
IDLE → UNDERSTANDING → INSPECTING → PLANNING ─┬─► EXECUTING → VERIFYING → COMPLETED
                                              │
                                              └─► AWAITING_APPROVAL ──(decision)──┘
                                        any step → FAILED
```

The run's `transcript`, `pending_tool_results` and `pending_approval_ids` are
persisted, so an interrupted or paused run resumes without re-executing anything.

## Idempotency

Two independent mechanisms:

* **Runtime-level:** every mutating call gets
  `sha256(run_id | tool | canonical_args)`. If a `SUCCEEDED` `ToolExecution` with
  that key already exists in the run, the prior result is replayed rather than
  re-executed (handles a lost response or a resumed run).
* **Tool-level (state-aware):** `create_field` re-describes the object with the
  cache bypassed immediately before deploying; if the field is already there it
  returns `already_exists` instead of deploying a duplicate.

## Verification

A tool is only reported as succeeded when Salesforce confirms the resulting
state:

| Tool | Verification |
|---|---|
| `create_record` | GET the new record, compare supplied field values |
| `update_record` | re-read the record, diff expected vs actual |
| `create_field` | `describe` the object again (cache bypassed), assert the field exists |
| `deploy_metadata` | re-read `checkDeployStatus` for the deploy id |

If verification fails, `success` is forced to `false` with
`VERIFICATION_FAILED`, so the model cannot report a change as complete.

## Context management

* Tool results are serialized with a hard character budget
  (`MAX_TOOL_RESULT_CHARS`); records are dropped from the tail by binary search
  and a truncation note is added so the model knows to paginate.
* `describe_object` supports `field_filter` / `fields` / `max_fields` for
  progressive disclosure instead of dumping wide objects.
* The transcript is compacted to the first turn plus a recent window, never
  cutting a message list so that it starts with an orphaned `tool_result`.

## Extending

Adding a capability means adding one module under `app/tools/` that registers a
`Tool` (name, description, input/output schema, risk, approval flag, execute,
validate, plan, verify). The runtime, risk engine, approval flow, audit and UI
need no changes. The designed-for set (`create_flow`, `generate_apex`,
`run_apex_tests`, `analyze_duplicates`, `inspect_permissions`, GitHub/Jira/Slack)
fits this contract.

## MCP

MCP is treated as one possible implementation behind a tool, not as the
architecture. The abstraction is `agent → tool registry → Salesforce
capability`; whether a given capability is served by REST, the Metadata API,
the Tooling API, Bulk, or an MCP server is an implementation detail of that
tool's `execute`. No MCP dependency is required to run the product.
