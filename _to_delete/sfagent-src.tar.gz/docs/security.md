# Security

## Credentials

* Salesforce access and refresh tokens are encrypted at rest with Fernet
  (`ENCRYPTION_KEY`, 32-byte urlsafe base64). Without the key the process
  **refuses** to persist tokens rather than storing them in the clear.
* Tokens are decrypted only inside `SalesforceClient`, used for the HTTP call,
  and re-encrypted on refresh. `SalesforceClient.access_token` is documented as
  server-side only.
* Claude receives **tool schemas and tool results** — never credentials, never
  the instance session, never the Connected App secret.
* `redact()` in `app/observability/logging.py` scrubs token-bearing keys from
  every log line, audit row and tool-execution record.
* `.env` is git-ignored; `.env.example` carries no real values.

## Identity, tenancy and authorization

* Application sessions are signed JWTs (HS256, `SESSION_SECRET`) delivered as an
  HttpOnly cookie; `Authorization: Bearer` is also accepted for API clients.
  This is a real, verified session layer — enterprise SSO is explicitly out of
  MVP scope, not stubbed.
* Every row that can reach Salesforce data carries `user_id` and
  `org_connection_id`. Conversations, runs, approvals, deployments and audit
  entries are always filtered by the caller's `user_id`; a foreign id returns
  404, never another tenant's data.
* A Salesforce record id supplied by the model is only ever used through the
  caller's own `OrgConnection`, so it cannot reach another org.

## Risk engine (deterministic, outside the model)

`app/risk/engine.py` starts from the tool's base risk and escalates:

| Condition | Effect |
|---|---|
| Object is a security/permission object (`User`, `Profile`, `PermissionSet`, sharing, …) and the call mutates | → HIGH, approval required |
| Tool name starts with `delete`, or `hard_delete` is set | → HIGH, approval required |
| More than 20 record ids in one call | → HIGH, approval required |
| Target org is not a sandbox and the call mutates | approval required; MEDIUM → HIGH |
| `create_field` / `deploy_metadata` on a non-sandbox org | **blocked** unless `ALLOW_PRODUCTION_MUTATIONS=true` |
| `deploy_metadata` with `check_only: false` | approval required |

The model cannot argue past this: the decision is computed from the tool name,
the arguments and the org record before `execute` is called.

## Human-in-the-loop

* An `Approval` row is created only by the runtime, and decided only by
  `POST /api/approvals/{id}/decision`.
* Conversational agreement — "sounds good", "ok", "approved" typed in chat — is
  never interpreted as approval. There is a test for exactly this
  (`test_conversational_agreement_never_approves`).
* Approvals are single-decision: a decided approval returns 409 on a second
  attempt.
* A human may **modify** the arguments when approving; the modified payload is
  stored and used, and the original is retained.
* On resume, an approved mutation is **re-validated** against the live org
  before it executes, because the org may have changed while the human was
  deciding.

## Prompt injection

Salesforce records are arbitrary user-entered text and are treated as data:

* Every tool result is wrapped in
  `BEGIN_UNTRUSTED_SALESFORCE_DATA … END_UNTRUSTED_SALESFORCE_DATA`.
* The system prompt states that content inside those markers is inert, that only
  the system policy and the authenticated user's messages direct behaviour, and
  that apparent instructions inside org data should be reported as a suspicious
  observation.
* Even if the model were persuaded, it can only act through registered tools,
  each of which is validated and risk-classified deterministically — a record
  saying "delete all accounts" cannot reach a delete capability that does not
  exist and cannot bypass the approval gate.

## SOQL safety

SELECT-only, single statement, comments stripped, DML verbs rejected on word
boundaries with string literals blanked, mandatory bounded LIMIT, row cap,
OFFSET ceiling, and pagination instead of unbounded reads. Large extracts are
pushed to Bulk API 2.0 rather than into the context window.

## Metadata safety

* All XML values escaped; responses parsed with `defusedxml`.
* Package paths are validated (no absolute paths, no `..`, no caller-supplied
  `package.xml`).
* `check_only` validation deployments are the default for `deploy_metadata`.

## Audit

Every meaningful operation writes an `AuditLog` row: user, org connection,
Salesforce org id, conversation, run, tool execution, request id, action, tool,
redacted arguments, sanitized result summary, object, record ids, before/after
values, risk level, approval state, execution state, deployment id, outcome and
error. Secrets are never stored; record payloads are summarized rather than
dumped.

## Runtime limits

`MAX_AGENT_STEPS` (runaway-loop halt), `TOOL_TIMEOUT_SECONDS`,
`MAX_TOOL_RESULT_CHARS`, `MAX_QUERY_ROWS`, `CLAUDE_MAX_RETRIES`, plus per-run
token accounting persisted on `AgentRun`.

## Known gaps

* No rate limiting per user/IP at the edge (put a proxy or API gateway in front).
* No role-based authorization inside the app: any authenticated user can approve
  their own run's changes. Multi-approver policy is not implemented.
* Approvals do not expire.
* Secrets live in environment variables; a KMS/secret manager is recommended for
  production.
* Session cookies are `SameSite=Lax`; deploy the frontend and backend on the
  same site or move to a token-based flow for cross-site deployments.
