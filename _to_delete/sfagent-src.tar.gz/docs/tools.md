# Tools

Every tool is registered in `app/tools/registry.py` with: name, description
(what Claude reads), input schema, output schema, risk level, approval flag,
execute, and optional validate / plan / verify hooks.

`GET /api/tools` returns the live catalogue.

| Tool | Risk | Approval | Salesforce API |
|---|---|---|---|
| `describe_object` | LOW | no | REST describe |
| `query_salesforce` | LOW | no | SOQL query / queryMore / Bulk API 2.0 query |
| `create_record` | MEDIUM | yes | REST sObject POST |
| `update_record` | MEDIUM | yes | REST sObject PATCH |
| `create_field` | MEDIUM (HIGH in prod) | yes | Metadata API deploy |
| `deploy_metadata` | HIGH | yes | Metadata API deploy |

Risk is a *base*; `app/risk/engine.py` escalates per call (see
[security.md](security.md)).

---

## describe_object

Schema inspection. Returns object permissions, field API names, types, lengths,
required/createable/updateable flags, picklist values, reference targets, and
optionally child relationships.

Progressive disclosure: `field_filter` (substring), `fields` (explicit list),
`max_fields` (default 120). Wide objects are truncated with an explicit note
rather than silently.

Unknown object → structured `NOT_FOUND` plus `similar_objects` from
`describe_global`, so the agent can self-correct instead of guessing.

```json
{"object": "Account", "field_filter": "tier", "include_relationships": false}
```

## query_salesforce

Read-only SOQL. `app/salesforce/soql.py` validates before execution:

* SELECT-only; DML verbs rejected on word boundaries with string literals blanked
  (so `WHERE Name LIKE '%update%'` is fine, `UPDATE Account` is not)
* one statement only; comments stripped
* LIMIT added when missing, capped at `MAX_QUERY_ROWS`
* OFFSET > 2000 rejected (Salesforce limit) with a pagination suggestion

Options: `max_records`, `follow_pagination` (nextRecordsUrl), `tooling` (Tooling
API objects such as ApexClass/Flow), `use_bulk_api` (Bulk API 2.0 job for large
extracts — returns the real job id).

Results carry `data_trust: "untrusted_external_data"` and are wrapped in
`BEGIN/END_UNTRUSTED_SALESFORCE_DATA` before reaching the model.

## create_record

Validated against the live describe before anything is written:

* unknown field → `INVALID_FIELD`
* non-createable field → `INVALID_FIELD_FOR_INSERT_UPDATE`
* restricted picklist mismatch → `FIELD_INTEGRITY_EXCEPTION` with allowed values
* missing required createable field → `REQUIRED_FIELD_MISSING` with the list,
  so the agent asks the user rather than inventing values

Plan → approval card → execute → GET the record → compare values.

## update_record

Same validation plus record-existence/visibility check. `plan` reads the current
values so the approval card shows a true old → new diff, and the audit row keeps
`before_values` / `after_values`.

## create_field

Metadata API field creation with an extensible type registry
(`FIELD_TYPES` in `app/salesforce/metadata.py`):

`Text, LongTextArea, Number, Currency, Percent, Checkbox, Date, DateTime, Email,
Phone, Url, Picklist, MultiselectPicklist, Lookup`

Each type declares its required options; a missing option produces
`METADATA_VALIDATION_ERROR` naming exactly what to ask the user for. API names
are normalized (`"Customer Tier"` → `Customer_Tier__c`) and all values are XML-escaped.

Flow: validate → describe (does it exist?) → build `package.xml` +
`objects/<Object>.object` (+ optional `profiles/<Profile>.profile` for
field-level security) → zip → `deploy()` → poll `checkDeployStatus()` →
re-describe to confirm the field exists → report.

`check_only: true` runs a real Salesforce validation deployment that saves nothing.

## deploy_metadata

Generic package deployment. You supply `files` (path + content, as they appear
inside a metadata zip) and `manifest` (type → members); `package.xml` is
generated. `check_only` defaults to **true**. `test_level` supports
`NoTestRun | RunSpecifiedTests | RunLocalTests | RunAllTestsInOrg`.

Returns deploy id, component totals/failures, test totals/failures, component
error details and Apex test failures with stack traces.

---

## Tool result contract

Success:

```json
{"success": true, "object": "Account", "count": 10, "records": [...]}
```

Failure — always actionable, never a stack trace:

```json
{
  "success": false,
  "error_type": "INVALID_FIELD_FOR_INSERT_UPDATE",
  "message": "Field(s) not createable on Account: CreatedDate.",
  "likely_cause": "The field is read-only, formula, auto-number or system-maintained.",
  "suggested_action": "Inspect the field with describe_object and choose a writable field.",
  "retryable": false,
  "fields": ["CreatedDate"]
}
```

`app/salesforce/errors.py` maps the Salesforce error codes that matter
(`INVALID_SESSION_ID`, `REQUIRED_FIELD_MISSING`, `DUPLICATES_DETECTED`,
`UNABLE_TO_LOCK_ROW`, `REQUEST_LIMIT_EXCEEDED`, …) to cause + action +
retryability.

## Adding a tool

```python
# app/tools/my_tool.py
TOOL = registry.register(Tool(
    name="inspect_permissions",
    description="...what Claude needs to know to choose this tool...",
    input_schema={...}, output_schema={...},
    risk=RiskLevel.LOW, requires_approval=False,
    execute=_execute, validate=_validate, plan=_plan, verify=_verify,
    mutating=False, audit_action="salesforce.inspect_permissions",
))
```

Then import it in `build_registry()`. Nothing else changes.
