# Development

## Layout

```
backend/
  app/
    agent/       runtime, Claude wrapper, prompts, context budgeting
    api/         FastAPI routers
    risk/        risk engine
    salesforce/  client, oauth, metadata, soql, errors
    security/    crypto, auth
    tools/       registry + one module per tool
    observability/logging
    config.py db.py models.py main.py
  tests/         unit, tool, agent and API tests
frontend/        Next.js console
docs/            this documentation
```

## Backend

```bash
cd backend
pip install -r requirements-dev.txt
cp ../.env.example .env      # then fill it in
uvicorn app.main:app --reload --port 8000
```

Tables are created on startup (`init_db`). SQLite is the local default; point
`DATABASE_URL` at Postgres for anything shared. Schema migrations are not wired
to Alembic yet — for the MVP, changing a model means recreating the local
database.

## Frontend

```bash
cd frontend
npm install
echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev
```

## Quality gates

```bash
cd backend
python -m pytest -q        # 69 tests
python -m ruff check .
cd ../frontend
npm run typecheck
npm run build
```

## What the tests cover

| File | Covers |
|---|---|
| `test_soql.py` | SELECT-only enforcement, LIMIT injection/capping, literals vs verbs, OFFSET ceiling |
| `test_metadata.py` | API-name normalization, per-type required options, package/zip shape, XML escaping |
| `test_risk.py` | escalation rules, production blocking, policy override |
| `test_tools.py` | each tool's validation and execution against a Salesforce double |
| `test_agent.py` | tool selection, untrusted-data framing, approval gate, "sounds good" is not approval, resume-after-approval, rejection, production block, max-step halt, unknown tool, missing connection |
| `test_api.py` | auth, tenancy isolation, tool catalogue, approval decision endpoint, SSE stream |

The Salesforce double is an `httpx.MockTransport` app in `tests/conftest.py`. It
is a test fixture, not a runtime stub — production code paths always call real
Salesforce APIs.

## Manual integration checklist (sandbox)

1. `GET /health` → `salesforce_configured` and `claude_configured` true.
2. Connect a sandbox org; confirm the connection validates.
3. "Inspect the Account object." → real field list.
4. "Find the 10 newest Accounts." → real records, LIMIT enforced.
5. "Create an Account called Integration Test Co." → approval card → approve →
   record id returned → verify in Salesforce.
6. "Create a Customer Tier picklist on Account with Enterprise, SMB and Startup."
   → approval card → approve → deploy id → field visible in Setup → the agent
   reports verified.
7. Repeat step 6 → the agent reports the field already exists and deploys nothing.
8. Point the conversation at a production org and repeat step 6 → blocked by policy.

## Debugging

Logs are JSON with `request_id` and `agent_run_id` on every line. Useful events:
`salesforce.http`, `claude.response`, `metadata.deploy_started`,
`metadata.deploy_finished`, `agent.run_failed`, `tool.unhandled_error`.

`GET /api/tool-executions?agent_run_id=…` shows exactly what ran, with duration,
risk, approval and execution state. `GET /api/deployments` shows deployment
outcomes including component and test failures.

## Conventions

* Never let a tool return an unstructured error; map it in
  `app/salesforce/errors.py` or return the `{success:false, error_type, …}` shape.
* Never mark a mutation successful without a `verify` implementation.
* Keep deterministic policy out of prompts and inside `risk/` and tool validators.
* Label anything incomplete explicitly in the tool description and the README.
