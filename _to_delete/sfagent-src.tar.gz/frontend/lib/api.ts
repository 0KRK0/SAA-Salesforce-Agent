import type {
  Approval,
  AuditEntry,
  ChatMessage,
  Connection,
  Conversation,
  UserOut,
} from "./types";

export const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000";

export class ApiError extends Error {
  status: number;
  detail: unknown;
  constructor(status: number, detail: unknown, message: string) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (!res.ok) {
    let detail: unknown = null;
    try {
      detail = await res.json();
    } catch {
      detail = await res.text();
    }
    const message =
      typeof detail === "object" && detail && "detail" in detail
        ? String((detail as { detail: unknown }).detail)
        : `Request failed (${res.status})`;
    throw new ApiError(res.status, detail, message);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  health: () => request<{ status: string; tools: string[]; model: string }>("/health"),

  me: () => request<UserOut>("/api/auth/me"),
  login: (email: string, display_name = "") =>
    request<UserOut>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, display_name }),
    }),
  logout: () => request<{ success: boolean }>("/api/auth/logout", { method: "POST" }),

  salesforceConfig: () =>
    request<{ configured: boolean; setup_hint: string | null; api_version: string }>(
      "/api/salesforce/config",
    ),
  connections: () => request<Connection[]>("/api/salesforce/connections"),
  startOAuth: (sandbox: boolean) =>
    request<{ authorize_url: string }>(
      `/api/salesforce/oauth/start?sandbox=${sandbox}`,
      { method: "POST" },
    ),
  validateConnection: (id: string) =>
    request<{ success: boolean; org: Record<string, unknown> }>(
      `/api/salesforce/connections/${id}/validate`,
      { method: "POST" },
    ),
  disconnect: (id: string) =>
    request<{ success: boolean }>(`/api/salesforce/connections/${id}`, {
      method: "DELETE",
    }),

  conversations: () => request<Conversation[]>("/api/conversations"),
  createConversation: (org_connection_id: string | null) =>
    request<Conversation>("/api/conversations", {
      method: "POST",
      body: JSON.stringify({ title: "New conversation", org_connection_id }),
    }),
  conversation: (id: string) =>
    request<{ conversation: Conversation; messages: ChatMessage[] }>(
      `/api/conversations/${id}`,
    ),
  setConversationOrg: (id: string, org_connection_id: string) =>
    request<Conversation>(`/api/conversations/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ org_connection_id }),
    }),
  deleteConversation: (id: string) =>
    request<{ success: boolean }>(`/api/conversations/${id}`, { method: "DELETE" }),

  approvals: (conversationId?: string) =>
    request<{ approvals: Approval[] }>(
      `/api/approvals${conversationId ? `?conversation_id=${conversationId}` : ""}`,
    ),
  decide: (
    id: string,
    decision: "approve" | "reject",
    note?: string,
    modified_arguments?: Record<string, unknown>,
  ) =>
    request<{ resume_ready: boolean; run_id: string }>(
      `/api/approvals/${id}/decision`,
      {
        method: "POST",
        body: JSON.stringify({ decision, note, modified_arguments }),
      },
    ),

  tools: () => request<{ tools: Array<Record<string, unknown>> }>("/api/tools"),
  audit: (conversationId?: string) =>
    request<{ entries: AuditEntry[] }>(
      `/api/audit${conversationId ? `?conversation_id=${conversationId}` : ""}`,
    ),
  deployments: () =>
    request<{ deployments: Array<Record<string, unknown>> }>("/api/deployments"),
};
