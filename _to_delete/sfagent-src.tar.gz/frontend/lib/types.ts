export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";

export interface UserOut {
  id: string;
  email: string;
  display_name: string;
}

export interface Connection {
  id: string;
  sf_org_id: string;
  username: string;
  instance_url: string;
  org_type: string;
  is_sandbox: boolean;
  api_version: string;
  is_active: boolean;
  last_validated_at: string | null;
}

export interface Conversation {
  id: string;
  title: string;
  org_connection_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  agent_run_id: string | null;
  created_at: string;
}

export interface PlanDetail {
  field: string;
  old_value?: unknown;
  new_value?: unknown;
}

export interface ChangePlan {
  title?: string;
  object?: string;
  record_id?: string;
  change_type?: string;
  summary?: string;
  details?: PlanDetail[];
  impact?: string;
  reason?: string;
  risk?: { risk: RiskLevel; reasons: string[]; requires_approval: boolean };
}

export interface Approval {
  id: string;
  agent_run_id: string;
  conversation_id: string;
  tool_name: string;
  risk_level: RiskLevel;
  state: "PENDING" | "APPROVED" | "REJECTED" | "EXPIRED" | "NOT_REQUIRED";
  arguments: Record<string, unknown> | null;
  plan: ChangePlan | null;
  decision_note: string | null;
  created_at: string;
}

/** One line in the visible execution trace (never internal reasoning). */
export interface TraceEntry {
  id: string;
  kind:
    | "state"
    | "tool"
    | "approval"
    | "deployment"
    | "error"
    | "info"
    | "assistant";
  label: string;
  detail?: string;
  status?: "running" | "ok" | "failed" | "blocked" | "waiting";
  risk?: RiskLevel;
  at: number;
}

export interface AuditEntry {
  id: string;
  action: string;
  tool_name: string | null;
  salesforce_object: string | null;
  record_ids: string[] | null;
  risk_level: RiskLevel | null;
  approval_state: string | null;
  execution_state: string | null;
  outcome: string;
  error: string | null;
  result_summary: Record<string, unknown> | null;
  before_values: Record<string, unknown> | null;
  after_values: Record<string, unknown> | null;
  agent_run_id: string | null;
  created_at: string;
}
