import { API_BASE } from "./api";

export interface AgentEvent {
  type: string;
  data: Record<string, unknown>;
}

/**
 * Consume a POST server-sent-event stream. EventSource cannot POST, so the
 * response body is parsed manually.
 */
export async function streamAgent(
  path: string,
  body: unknown,
  onEvent: (event: AgentEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  });

  if (!res.ok || !res.body) {
    let message = `Agent request failed (${res.status})`;
    try {
      const detail = await res.json();
      if (detail?.detail) message = String(detail.detail);
    } catch {
      /* keep default message */
    }
    onEvent({ type: "error", data: { message } });
    onEvent({ type: "stream.end", data: {} });
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let boundary = buffer.indexOf("\n\n");
    while (boundary !== -1) {
      const chunk = buffer.slice(0, boundary);
      buffer = buffer.slice(boundary + 2);
      const event = parseChunk(chunk);
      if (event) onEvent(event);
      boundary = buffer.indexOf("\n\n");
    }
  }
}

function parseChunk(chunk: string): AgentEvent | null {
  let type = "message";
  const dataLines: string[] = [];
  for (const line of chunk.split("\n")) {
    if (line.startsWith("event:")) type = line.slice(6).trim();
    else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
  }
  if (!dataLines.length) return null;
  try {
    return { type, data: JSON.parse(dataLines.join("\n")) };
  } catch {
    return { type, data: { raw: dataLines.join("\n") } };
  }
}
