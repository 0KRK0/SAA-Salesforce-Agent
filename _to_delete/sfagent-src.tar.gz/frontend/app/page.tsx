"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ApprovalCard } from "@/components/ApprovalCard";
import { Shell } from "@/components/Shell";
import { Trace } from "@/components/Trace";
import { api } from "@/lib/api";
import { streamAgent, type AgentEvent } from "@/lib/sse";
import type {
  Approval,
  ChatMessage,
  Connection,
  Conversation,
  RiskLevel,
  TraceEntry,
} from "@/lib/types";

let seq = 0;
const nextId = () => `t${++seq}`;

export default function ChatPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [trace, setTrace] = useState<TraceEntry[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const connection = connections.find(
    (c) => c.id === conversations.find((x) => x.id === currentId)?.org_connection_id,
  );

  const refreshConversations = useCallback(async () => {
    const list = await api.conversations();
    setConversations(list);
    return list;
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [convs, conns] = await Promise.all([api.conversations(), api.connections()]);
        setConversations(convs);
        setConnections(conns);
        if (convs.length) setCurrentId(convs[0].id);
      } catch {
        /* unauthenticated — Shell renders the login gate */
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentId) return;
    (async () => {
      const detail = await api.conversation(currentId);
      setMessages(detail.messages);
      setTrace([]);
      const { approvals: list } = await api.approvals(currentId);
      setApprovals(list.filter((a) => a.state === "PENDING"));
    })();
  }, [currentId]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, trace, approvals]);

  const push = (entry: Omit<TraceEntry, "id" | "at">) =>
    setTrace((prev) => [...prev, { ...entry, id: nextId(), at: Date.now() }]);

  const handleEvent = useCallback((ev: AgentEvent) => {
    const d = ev.data as Record<string, any>;
    switch (ev.type) {
      case "run.started":
        push({ kind: "info", label: "Run started", detail: String(d.model ?? ""), status: "running" });
        break;
      case "state":
        push({ kind: "state", label: humanState(String(d.state)), status: "running" });
        break;
      case "tool.started":
        push({
          kind: "tool",
          label: describeTool(String(d.tool), d.arguments),
          status: "running",
          risk: d.risk as RiskLevel,
        });
        break;
      case "tool.verifying":
        push({ kind: "tool", label: "Verifying the change in Salesforce…", status: "running" });
        break;
      case "tool.finished":
        push({
          kind: "tool",
          label: `${d.tool} succeeded`,
          detail: summarize(d.summary),
          status: "ok",
        });
        break;
      case "tool.failed":
        push({
          kind: "tool",
          label: `${d.tool ?? "tool"} failed`,
          detail: String(d.error ?? summarize(d.summary)),
          status: "failed",
        });
        break;
      case "tool.blocked":
        push({ kind: "tool", label: `${d.tool} blocked by policy`, detail: String(d.reason), status: "blocked" });
        break;
      case "tool.idempotent_hit":
        push({ kind: "info", label: `${d.tool}: already applied in this run`, status: "ok" });
        break;
      case "deployment.started":
        push({ kind: "deployment", label: "Deploying metadata…", status: "running" });
        break;
      case "approval.requested":
        push({ kind: "approval", label: "Waiting for human approval", status: "waiting" });
        setApprovals((prev) => [
          ...prev,
          {
            id: String(d.approval_id),
            agent_run_id: String(d.run_id ?? ""),
            conversation_id: "",
            tool_name: String(d.tool),
            risk_level: d.risk as RiskLevel,
            state: "PENDING",
            arguments: null,
            plan: { ...(d.plan ?? {}), risk: { risk: d.risk, reasons: d.reasons ?? [], requires_approval: true } },
            decision_note: null,
            created_at: new Date().toISOString(),
          },
        ]);
        break;
      case "approval.approved":
        push({ kind: "approval", label: `Approved — executing ${d.tool}`, status: "ok" });
        break;
      case "approval.rejected":
        push({ kind: "approval", label: "Rejected — no change was made", status: "blocked" });
        break;
      case "assistant.text":
        break;
      case "run.paused":
        setApprovals((prev) =>
          prev.map((a) => (a.agent_run_id ? a : { ...a, agent_run_id: String(d.run_id) })),
        );
        break;
      case "run.halted":
        push({ kind: "error", label: String(d.message ?? "Run halted"), status: "failed" });
        break;
      case "run.completed":
        push({
          kind: "info",
          label: "Run completed",
          detail: `${d.steps} steps · ${d.input_tokens}/${d.output_tokens} tokens · ${Math.round(Number(d.duration_ms))}ms`,
          status: "ok",
        });
        break;
      case "error":
        setError(String(d.message));
        push({ kind: "error", label: String(d.message), status: "failed" });
        break;
      default:
        break;
    }
  }, []);

  async function reloadMessages(conversationId: string) {
    const detail = await api.conversation(conversationId);
    setMessages(detail.messages);
    await refreshConversations();
  }

  async function send() {
    const text = input.trim();
    if (!text || running) return;
    let conversationId = currentId;
    if (!conversationId) {
      const created = await api.createConversation(connections[0]?.id ?? null);
      await refreshConversations();
      setCurrentId(created.id);
      conversationId = created.id;
    }
    setInput("");
    setError(null);
    setRunning(true);
    setMessages((prev) => [
      ...prev,
      {
        id: `local-${Date.now()}`,
        role: "user",
        text,
        agent_run_id: null,
        created_at: new Date().toISOString(),
      },
    ]);
    try {
      await streamAgent(
        `/api/conversations/${conversationId}/messages`,
        { message: text },
        handleEvent,
      );
    } finally {
      setRunning(false);
      await reloadMessages(conversationId);
    }
  }

  async function decide(
    id: string,
    decision: "approve" | "reject",
    note?: string,
    modified?: Record<string, unknown>,
  ) {
    const result = await api.decide(id, decision, note, modified);
    setApprovals((prev) => prev.filter((a) => a.id !== id));
    if (result.resume_ready) {
      setRunning(true);
      try {
        await streamAgent(`/api/runs/${result.run_id}/resume`, undefined, handleEvent);
      } finally {
        setRunning(false);
        if (currentId) await reloadMessages(currentId);
      }
    }
  }

  return (
    <Shell
      active="chat"
      conversations={conversations}
      currentConversationId={currentId}
      onSelectConversation={setCurrentId}
      onNewConversation={async () => {
        const created = await api.createConversation(connections[0]?.id ?? null);
        await refreshConversations();
        setCurrentId(created.id);
        setMessages([]);
        setTrace([]);
        setApprovals([]);
      }}
      topbar={
        <>
          <strong>{conversations.find((c) => c.id === currentId)?.title ?? "Agent"}</strong>
          <div className="row-between" style={{ gap: 8 }}>
            {connection ? (
              <>
                <span className="muted">{connection.username}</span>
                <span className={`badge ${connection.is_sandbox ? "sandbox" : "HIGH"}`}>
                  {connection.is_sandbox ? "SANDBOX" : "PRODUCTION"}
                </span>
              </>
            ) : (
              <a href="/connections">Connect a Salesforce org →</a>
            )}
          </div>
        </>
      }
    >
      <div className="content">
        {!connections.length && (
          <div className="page">
            <div className="banner">
              No Salesforce org is connected. The agent can talk, but every Salesforce
              tool will fail until you <a href="/connections">connect an org</a>.
            </div>
          </div>
        )}
        {error && (
          <div className="page">
            <div className="banner error">{error}</div>
          </div>
        )}
        {!messages.length && !trace.length && (
          <div className="empty">
            <p>Ask the agent to inspect, query or change your Salesforce org.</p>
            <div className="stack" style={{ maxWidth: 420, margin: "0 auto" }}>
              {[
                "Inspect the Account object.",
                "Find the 10 newest Accounts.",
                "Create a Customer Tier picklist on Account with Enterprise, SMB and Startup.",
              ].map((s) => (
                <button key={s} className="ghost" onClick={() => setInput(s)}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m) => (
          <div className={`msg ${m.role}`} key={m.id}>
            <div className="who">{m.role === "user" ? "You" : "Agent"}</div>
            <div className="body">{m.text}</div>
          </div>
        ))}

        <Trace entries={trace} />

        {approvals.map((a) => (
          <ApprovalCard key={a.id} approval={a} onDecide={decide} />
        ))}
        <div ref={bottom} />
      </div>

      <div className="composer">
        <div className="row">
          <textarea
            placeholder="Describe what you want to do in Salesforce…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
          />
          <button className="primary" disabled={running || !input.trim()} onClick={() => void send()}>
            {running ? "Working…" : "Send"}
          </button>
        </div>
      </div>
    </Shell>
  );
}

function humanState(state: string): string {
  const map: Record<string, string> = {
    UNDERSTANDING: "Understanding the request…",
    INSPECTING: "Inspecting Salesforce…",
    PLANNING: "Planning the next step…",
    AWAITING_APPROVAL: "Waiting for approval",
    EXECUTING: "Executing…",
    VALIDATING: "Validating…",
    VERIFYING: "Verifying the result…",
    COMPLETED: "Completed",
    FAILED: "Failed",
  };
  return map[state] ?? state;
}

function describeTool(tool: string, args: unknown): string {
  const a = (args ?? {}) as Record<string, any>;
  switch (tool) {
    case "describe_object":
      return `Inspecting ${a.object} schema…`;
    case "query_salesforce":
      return "Querying Salesforce…";
    case "create_record":
      return `Preparing to create a ${a.object} record…`;
    case "update_record":
      return `Preparing to update ${a.object} ${a.record_id}…`;
    case "create_field":
      return `Preparing field ${a.api_name} on ${a.object}…`;
    case "deploy_metadata":
      return a.check_only === false ? "Deploying metadata…" : "Validating metadata…";
    default:
      return `Running ${tool}…`;
  }
}

function summarize(summary: unknown): string {
  if (!summary || typeof summary !== "object") return "";
  const s = summary as Record<string, unknown>;
  const parts: string[] = [];
  if (s.object) parts.push(String(s.object));
  if (s.count !== undefined) parts.push(`${s.count} records`);
  if (s.record_id) parts.push(String(s.record_id));
  if (s.field) parts.push(String(s.field));
  if (s.deploy_id) parts.push(`deploy ${s.deploy_id}`);
  if (s.verified !== undefined) parts.push(s.verified ? "verified" : "unverified");
  return parts.join(" · ");
}
