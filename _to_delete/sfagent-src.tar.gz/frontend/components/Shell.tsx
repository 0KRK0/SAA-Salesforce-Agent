"use client";

import { useEffect, useState } from "react";
import { api, ApiError } from "@/lib/api";
import type { Conversation, UserOut } from "@/lib/types";

interface ShellProps {
  children: React.ReactNode;
  active: "chat" | "connections" | "audit";
  conversations?: Conversation[];
  currentConversationId?: string | null;
  onSelectConversation?: (id: string) => void;
  onNewConversation?: () => void;
  topbar?: React.ReactNode;
}

export function Shell({
  children,
  active,
  conversations = [],
  currentConversationId,
  onSelectConversation,
  onNewConversation,
  topbar,
}: ShellProps) {
  const { user, loading, login, logout } = useSession();

  if (loading) {
    return <div className="empty">Loading…</div>;
  }
  if (!user) {
    return <LoginGate onLogin={login} />;
  }

  return (
    <div className="layout">
      <aside className="sidebar">
        <header>
          <div className="brand">
            Salesforce AI Agent
            <small>Engineering console</small>
          </div>
        </header>
        <nav className="nav">
          <a href="/" className={active === "chat" ? "active" : ""}>
            Conversations
          </a>
          <a href="/connections" className={active === "connections" ? "active" : ""}>
            Salesforce connection
          </a>
          <a href="/audit" className={active === "audit" ? "active" : ""}>
            Audit history
          </a>
        </nav>
        {active === "chat" && (
          <>
            <div style={{ padding: "10px 10px 0" }}>
              <button style={{ width: "100%" }} onClick={onNewConversation}>
                + New conversation
              </button>
            </div>
            <div className="conv-list">
              {conversations.map((c) => (
                <div
                  key={c.id}
                  className={`conv-item ${c.id === currentConversationId ? "active" : ""}`}
                  onClick={() => onSelectConversation?.(c.id)}
                >
                  {c.title}
                </div>
              ))}
              {!conversations.length && (
                <div className="muted" style={{ padding: 10, fontSize: 12 }}>
                  No conversations yet.
                </div>
              )}
            </div>
          </>
        )}
        <footer>
          <div className="row-between">
            <span>{user.email}</span>
            <button className="ghost" onClick={logout} style={{ padding: "2px 8px" }}>
              Sign out
            </button>
          </div>
        </footer>
      </aside>
      <main className="main">
        <div className="topbar">{topbar}</div>
        {children}
      </main>
    </div>
  );
}

export function useSession() {
  const [user, setUser] = useState<UserOut | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .me()
      .then(setUser)
      .catch((err) => {
        if (!(err instanceof ApiError) || err.status !== 401) console.error(err);
      })
      .finally(() => setLoading(false));
  }, []);

  return {
    user,
    loading,
    login: async (email: string) => setUser(await api.login(email)),
    logout: async () => {
      await api.logout();
      setUser(null);
    },
  };
}

function LoginGate({ onLogin }: { onLogin: (email: string) => Promise<void> }) {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  return (
    <div className="content">
      <div className="page" style={{ maxWidth: 380, marginTop: "12vh" }}>
        <div className="card">
          <h3>Sign in</h3>
          <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>
            Local identity for this deployment. Enterprise SSO is out of MVP scope.
          </p>
          <form
            className="stack"
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              setError(null);
              try {
                await onLogin(email);
              } catch (err) {
                setError(err instanceof Error ? err.message : "Sign-in failed");
              } finally {
                setBusy(false);
              }
            }}
          >
            <input
              type="email"
              required
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button className="primary" disabled={busy || !email}>
              {busy ? "Signing in…" : "Continue"}
            </button>
          </form>
          {error && (
            <div className="banner error" style={{ marginTop: 12 }}>
              {error}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
