"use client";

import { useState } from "react";
import type { Approval } from "@/lib/types";

interface Props {
  approval: Approval;
  onDecide: (
    id: string,
    decision: "approve" | "reject",
    note?: string,
    modified?: Record<string, unknown>,
  ) => Promise<void>;
}

export function ApprovalCard({ approval, onDecide }: Props) {
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(() =>
    JSON.stringify(approval.arguments ?? {}, null, 2),
  );
  const [error, setError] = useState<string | null>(null);
  const plan = approval.plan ?? {};
  const decided = approval.state !== "PENDING";

  async function decide(decision: "approve" | "reject") {
    setBusy(true);
    setError(null);
    try {
      let modified: Record<string, unknown> | undefined;
      if (editing && decision === "approve") {
        modified = JSON.parse(draft) as Record<string, unknown>;
      }
      await onDecide(approval.id, decision, undefined, modified);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Decision failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="approval">
      <header>
        <strong>{plan.title ?? `Approve ${approval.tool_name}`}</strong>
        <span className={`badge ${approval.risk_level}`}>{approval.risk_level} RISK</span>
      </header>
      <div className="body">
        {plan.summary && <p style={{ marginTop: 0 }}>{plan.summary}</p>}
        {!!plan.details?.length && (
          <table>
            <tbody>
              {plan.details.map((d, i) => (
                <tr key={i}>
                  <td>{d.field}</td>
                  <td>
                    {d.old_value !== undefined && d.old_value !== null && (
                      <>
                        <span className="old">{format(d.old_value)}</span>{" "}
                      </>
                    )}
                    <span className="new">{format(d.new_value)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {plan.impact && (
          <p className="muted" style={{ fontSize: 13 }}>
            <strong>Impact:</strong> {plan.impact}
          </p>
        )}
        {!!plan.risk?.reasons?.length && (
          <p className="muted" style={{ fontSize: 12 }}>
            {plan.risk.reasons.join(" ")}
          </p>
        )}
        {editing && (
          <textarea
            rows={10}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            style={{ fontFamily: "var(--mono)", fontSize: 12 }}
          />
        )}
        {error && <div className="banner error">{error}</div>}
      </div>
      <div className="actions">
        {decided ? (
          <span className="muted">
            {approval.state === "APPROVED" ? "Approved" : "Rejected"} — this decision is
            recorded in the audit log.
          </span>
        ) : (
          <>
            <button className="primary" disabled={busy} onClick={() => decide("approve")}>
              Approve
            </button>
            <button className="danger" disabled={busy} onClick={() => decide("reject")}>
              Reject
            </button>
            <button className="ghost" disabled={busy} onClick={() => setEditing((v) => !v)}>
              {editing ? "Cancel edit" : "Modify"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function format(value: unknown): string {
  if (value === null || value === undefined) return "—";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}
